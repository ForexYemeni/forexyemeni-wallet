import { NextRequest, NextResponse } from 'next/server'
import { userOperations, depositOperations, notificationOperations } from '@/lib/db-firebase'
import { sendPushNotification } from '@/lib/push-notification'
import { getDb } from '@/lib/firebase'
import { sendAdminNewDepositEmail } from '@/lib/email'

// GET - Check if user has a pending deposit
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ success: false, message: 'معرف المستخدم مطلوب' }, { status: 400 })
    }

    const db = getDb()
    const pendingDocs = await db.collection('deposits')
      .where('userId', '==', userId)
      .where('status', 'in', ['pending', 'reviewing'])
      .limit(1)
      .get()

    if (!pendingDocs.empty) {
      const deposit = pendingDocs.docs[0].data()
      return NextResponse.json({
        hasPending: true,
        deposit: { id: pendingDocs.docs[0].id, amount: deposit.amount, status: deposit.status, createdAt: deposit.createdAt }
      })
    }

    return NextResponse.json({ hasPending: false })
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ'
    return NextResponse.json({ success: false, message }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { userId, amount, method = 'blockchain', txId, screenshot, network } = await request.json()

    if (!userId || !amount) {
      return NextResponse.json(
        { success: false, message: 'معرف المستخدم والمبلغ مطلوبان' },
        { status: 400 }
      )
    }

    if (amount <= 0) {
      return NextResponse.json(
        { success: false, message: 'المبلغ يجب أن يكون أكبر من صفر' },
        { status: 400 }
      )
    }

    if (!screenshot) {
      return NextResponse.json(
        { success: false, message: 'صورة إثبات الدفع مطلوبة' },
        { status: 400 }
      )
    }

    const user = await userOperations.findUnique({ id: userId })
    if (!user) {
      return NextResponse.json(
        { success: false, message: 'المستخدم غير موجود' },
        { status: 404 }
      )
    }

    // Check for existing pending deposit
    const db = getDb()
    const pendingDeposits = await db.collection('deposits')
      .where('userId', '==', userId)
      .where('status', 'in', ['pending', 'reviewing'])
      .limit(1)
      .get()
    if (!pendingDeposits.empty) {
      return NextResponse.json(
        { success: false, message: 'لديك طلب إيداع معلق بالفعل، يرجى الانتظار حتى يتم معالجته قبل تقديم طلب جديد' },
        { status: 400 }
      )
    }

    // Fetch deposit fee from settings
    const settingsDoc = await db.collection('systemSettings').doc('fees').get()
    const depositFeePercentage = settingsDoc.exists ? (settingsDoc.data().depositFee || 0) : 0

    // Calculate fee and net amount
    const fee = amount * (depositFeePercentage / 100)
    const netAmount = amount - fee

    const deposit = await depositOperations.create({
      userId,
      amount,
      fee,
      netAmount,
      currency: 'USDT',
      network: network || 'TRC20',
      txId: txId || null,
      fromAddress: null,
      toAddress: null,
      method: method || 'blockchain',
      merchantId: null,
      merchantNote: null,
      screenshot: screenshot || null,
      status: 'pending',
    })

    // Notify admin(s) about new deposit request
    try {
      const adminDocs = await db.collection('users').where('role', '==', 'admin').get()
      for (const adminDoc of adminDocs.docs) {
        const admin = adminDoc.data() as any
        const adminId = adminDoc.id
        const title = 'طلب إيداع جديد'
        const feeInfo = depositFeePercentage > 0 ? ` (الرسوم: ${fee.toFixed(2)} USDT - الصافي: ${netAmount.toFixed(2)} USDT)` : ''
        const message = `طلب إيداع بقيمة ${amount} USDT من ${user.fullName || user.email}${feeInfo}`
        await notificationOperations.create({ userId: adminId, title, message, type: 'info', read: false })
        sendPushNotification(adminId, title, message, 'info').catch(() => {})

        // Send email to admin
        sendAdminNewDepositEmail(
          admin.email,
          user.fullName || user.email,
          user.email,
          amount,
          fee,
          netAmount,
          network || 'TRC20',
          deposit.id
        )
      }
    } catch {}

    return NextResponse.json({
      success: true,
      message: 'تم إنشاء طلب الإيداع بنجاح',
      deposit,
    })
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ'
    return NextResponse.json(
      { success: false, message },
      { status: 500 }
    )
  }
}
