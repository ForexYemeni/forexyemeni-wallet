/**
 * One-time script to unlock the admin account in Firestore.
 * 
 * Usage: FIREBASE_SERVICE_ACCOUNT='...' bun scripts/unlock-admin.ts
 * 
 * Steps:
 * 1. Finds the admin user by email in the `users` collection
 * 2. Updates `status` to 'active' and `mustChangePassword` to false
 * 3. Deletes the `pendingDeviceAuth` document for this user
 * 4. Deletes all `userDevices` documents for this user
 */

import { initializeApp, cert, getApps } from 'firebase-admin/app'
import { getFirestore } from 'firebase-admin/firestore'

const ADMIN_EMAIL = 'mshay2024m@gmail.com'

async function main() {
  // --- Init Firebase ---
  const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT
  if (!serviceAccountJson) {
    console.error('ERROR: FIREBASE_SERVICE_ACCOUNT environment variable is not set.')
    console.error('Expected a JSON string of the Firebase service account key.')
    process.exit(1)
  }

  let serviceAccountObj: any
  try {
    serviceAccountObj = JSON.parse(serviceAccountJson)
  } catch {
    console.error('ERROR: FIREBASE_SERVICE_ACCOUNT contains invalid JSON.')
    process.exit(1)
  }

  const app = getApps().length === 0
    ? initializeApp({ credential: cert(serviceAccountObj) })
    : getApps()[0]

  const db = getFirestore(app)

  console.log('Firebase initialized successfully.\n')

  // --- Step 1: Find the admin user ---
  console.log(`Looking for user with email: ${ADMIN_EMAIL} ...`)
  const userSnapshot = await db
    .collection('users')
    .where('email', '==', ADMIN_EMAIL)
    .limit(1)
    .get()

  if (userSnapshot.empty) {
    console.error(`ERROR: No user found with email "${ADMIN_EMAIL}".`)
    process.exit(1)
  }

  const userDoc = userSnapshot.docs[0]
  const userId = userDoc.id
  const userData = userDoc.data()

  console.log(`Found user: ID=${userId}`)
  console.log(`  Current status: ${userData.status}`)
  console.log(`  Current mustChangePassword: ${userData.mustChangePassword}`)
  console.log(`  Role: ${userData.role}`)
  console.log(`  Full name: ${userData.fullName || '(none)'}`)
  console.log()

  // --- Step 2: Update status and mustChangePassword ---
  console.log('Updating user document...')
  await db.collection('users').doc(userId).update({
    status: 'active',
    mustChangePassword: false,
    updatedAt: new Date().toISOString(),
  })
  console.log('  ✓ status set to "active"')
  console.log('  ✓ mustChangePassword set to false')
  console.log()

  // --- Step 3: Delete pendingDeviceAuth document ---
  console.log('Checking for pendingDeviceAuth document...')
  const pendingDoc = await db.collection('pendingDeviceAuth').doc(userId).get()
  if (pendingDoc.exists) {
    const pendingData = pendingDoc.data()
    console.log(`  Found pendingDeviceAuth: fingerprint=${pendingData.fingerprint}, device=${pendingData.deviceName}`)
    await db.collection('pendingDeviceAuth').doc(userId).delete()
    console.log('  ✓ pendingDeviceAuth document deleted')
  } else {
    console.log('  No pendingDeviceAuth document found (already clean)')
  }
  console.log()

  // --- Step 4: Delete all userDevices documents ---
  console.log('Checking for userDevices documents...')
  const devicesSnapshot = await db
    .collection('userDevices')
    .where('userId', '==', userId)
    .get()

  if (devicesSnapshot.empty) {
    console.log('  No userDevices documents found (already clean)')
  } else {
    console.log(`  Found ${devicesSnapshot.size} device(s):`)
    const batch = db.batch()
    for (const doc of devicesSnapshot.docs) {
      const d = doc.data()
      console.log(`    - ${doc.id}: fingerprint=${d.fingerprint}, name=${d.deviceName}, active=${d.isActive}`)
      batch.delete(doc.ref)
    }
    await batch.commit()
    console.log(`  ✓ All ${devicesSnapshot.size} userDevices document(s) deleted`)
  }
  console.log()

  // --- Summary ---
  console.log('========================================')
  console.log('  ADMIN ACCOUNT UNLOCKED SUCCESSFULLY')
  console.log('========================================')
  console.log(`  Email: ${ADMIN_EMAIL}`)
  console.log(`  User ID: ${userId}`)
  console.log(`  Status: active`)
  console.log(`  mustChangePassword: false`)
  console.log(`  Devices cleared: all removed`)
  console.log('========================================')
  console.log('\nThe admin can now log in from any device without device restrictions.')
}

main().catch((err) => {
  console.error('FATAL ERROR:', err)
  process.exit(1)
})
