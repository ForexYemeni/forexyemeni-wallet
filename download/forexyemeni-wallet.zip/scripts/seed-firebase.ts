import { seedDatabase } from '../src/lib/db-firebase'

async function main() {
  console.log('🌱 Seeding Firebase Firestore database...')
  try {
    await seedDatabase()
    console.log('✅ Seed completed successfully!')
    process.exit(0)
  } catch (error) {
    console.error('❌ Seed failed:', error)
    process.exit(1)
  }
}

main()
