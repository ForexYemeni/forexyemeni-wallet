import { apiFetch } from '@/lib/api-client'
'use client'

import { useState, useEffect, useRef, useCallback, lazy, Suspense } from 'react'
import dynamic from 'next/dynamic'
import { useAuthStore } from '@/lib/store'
import { Portal } from '@/components/ui/portal'
import { toast } from 'sonner'
import { convertUSDTtoYER, formatYER, refreshExchangeRates } from '@/lib/currency'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { compressImage, fileToBase64 } from '@/lib/image-compress'
import {
  Users,
  ArrowDownLeft,
  ArrowUpRight,
  Shield,
  Loader2,
  Check,
  X,
  Search,
  Eye,
  Mail,
  Phone,
  DollarSign,
  BadgeCheck,
  Clock,
  UserCheck,
  UserX,
  Crown,
  ChevronDown,
  ChevronUp,
  Star,
  Ban,
  CreditCard,
  Plus,
  Wallet,
  Building,
  Trash2,
  Power,
  AlertTriangle,
  Lock,
  Send,
  Copy,
  Check as CheckIcon,
  Settings,
  Upload,
  ImageOff,
  TrendingUp,
  Activity,
  BarChart3,
  ArrowDownCircle,
  ArrowUpCircle,
  FileCheck,
  MessageCircle,
  MessageSquare,
  Gift,
  Repeat,
  Store,
  KeyRound,
  Percent,
  RefreshCw,
  RotateCcw,
  ShieldOff,
  Hash,
  Smartphone,
  Database,
  XCircle,
  FileText,
} from 'lucide-react'

// ===================== TYPES =====================

interface AdminUser {
  id: string
  email: string
  fullName: string | null
  phone: string | null
  role: string
  status: string
  emailVerified: boolean
  phoneVerified: boolean
  kycStatus: string
  balance: number
  frozenBalance: number
  country: string | null
  createdAt: string
  merchantId?: string | null
  accountNumber?: string | null
  twoFactorEnabled?: boolean | null
}

interface AdminDeposit {
  id: string
  amount: number
  fee?: number
  netAmount?: number
  txId: string | null
  status: string
  createdAt: string
  screenshot?: string | null
  user: { id: string; email: string; fullName: string | null }
}

interface AdminWithdrawal {
  id: string
  amount: number
  fee: number
  netAmount?: number
  toAddress: string
  method: string
  network: string
  status: string
  createdAt: string
  screenshot?: string | null
  adminNote?: string | null
  paymentMethodName?: string | null
  user: { id: string; email: string; fullName: string | null; phone: string | null }
}

interface AdminStats {
  totalUsers: number
  activeUsers: number
  suspendedUsers: number
  newUsersToday: number
  newUsersThisWeek: number
  newUsersThisMonth: number
  kycApproved: number
  kycPending: number
  kycRejected: number
  kycRecordsPending: number
  depositsPending: number
  depositsReviewing: number
  depositsConfirmed: number
  depositsRejected: number
  totalDepositsAmount: number
  totalDepositFees: number
  depositsTodayCount: number
  depositsTodayAmount: number
  depositsThisWeekAmount: number
  depositsThisMonthAmount: number
  withdrawalsPending: number
  withdrawalsApproved: number
  withdrawalsProcessing: number
  withdrawalsRejected: number
  totalWithdrawalsAmount: number
  totalWithdrawalFees: number
  withdrawalsTodayCount: number
  withdrawalsTodayAmount: number
  withdrawalsThisWeekAmount: number
  withdrawalsThisMonthAmount: number
  totalFees: number
  adminBalance: number
  pendingActions: number
  depositsPending: number
  depositsReviewing: number
  withdrawalsPending: number
  withdrawalsApproved: number
  kycRecordsPending: number
  recentActivity: any[]
}

interface KYCRecordItem {
  id: string
  type: string
  fileUrl: string
  status: string
  userId: string
  notes?: string | null
  user: { id: string; email: string; fullName: string | null; phone: string | null }
}

// ===================== ROLE MANAGEMENT =====================

type AdminPermission = {
  manageUsers: boolean
  approveDeposits: boolean
  approveWithdrawals: boolean
  approveKYC: boolean
  manageSettings: boolean
}

const DEFAULT_PERMISSIONS: AdminPermission = {
  manageUsers: true,
  approveDeposits: true,
  approveWithdrawals: true,
  approveKYC: true,
  manageSettings: false,
}

const ROLE_LABELS: Record<string, string> = {
  user: 'مستخدم',
  admin: 'مدير عام',
  moderator: 'مشرف',
  kyc_manager: 'مدير تحقق',
  finance_manager: 'مدير مالي',
}

// ===================== MAIN COMPONENT =====================

export default function AdminPanel() {
  const { user, setScreen } = useAuthStore()
  const AdminFaqManager = lazy(() => import('@/components/admin/AdminFaqManager'))
  const AdminReferralSettings = lazy(() => import('@/components/admin/AdminReferralSettings'))
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'deposits' | 'withdrawals' | 'kyc' | 'payment-methods' | 'admin-settings' | 'faq-bot' | 'chats' | 'referral-settings' | 'p2p' | 'audit-log' | 'reports' | 'system-monitor' | 'admin-team' | 'admin-financial' | 'banners' | 'super-admin' | 'promo' | 'withdrawal-reports' | 'firebase-config'>('dashboard')
  const AdminChat = lazy(() => import('@/components/admin/AdminChat'))
  const AdminP2P = lazy(() => import('@/components/admin/AdminP2P'))
  const AdminAuditLog = lazy(() => import('@/components/admin/AdminAuditLog'))
  const AdminReports = lazy(() => import('@/components/admin/AdminReports'))
  const AdminSystemMonitor = lazy(() => import('@/components/admin/AdminSystemMonitor'))
  const SuperAdminPanel = dynamic(() => import('@/components/admin/SuperAdminPanel'), { ssr: false })
  const AdminTeam = dynamic(() => import('@/components/admin/AdminTeam'), { ssr: false })
  const AdminFinancial = lazy(() => import('@/components/admin/AdminFinancial'))
  const BannerManager = lazy(() => import('@/components/admin/BannerManager'))
  const PromoManager = lazy(() => import('@/components/admin/PromoManager'))
  const AdminWithdrawalReports = lazy(() => import('@/components/admin/AdminWithdrawalReports'))
  const FirebaseConfig = lazy(() => import('@/components/admin/FirebaseConfig'))
  const [chatUnreadCount, setChatUnreadCount] = useState(0)

  // Fetch data when switching tabs (lazy load)
  const [users, setUsers] = useState<AdminUser[]>([])
  const [deposits, setDeposits] = useState<AdminDeposit[]>([])
  const [withdrawals, setWithdrawals] = useState<AdminWithdrawal[]>([])
  const [kycRecords, setKycRecords] = useState<KYCRecordItem[]>([])
  const [paymentMethods, setPaymentMethods] = useState<any[]>([])
  const [adminSettings, setAdminSettings] = useState<{ email: string; phone: string | null; hasPIN: boolean }>({ email: user?.email || '', phone: user?.phone || null, hasPIN: !!user?.hasPin || false })
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [expandedUserId, setExpandedUserId] = useState<string | null>(null)
  const [expandedDepositId, setExpandedDepositId] = useState<string | null>(null)
  const [expandedWithdrawalId, setExpandedWithdrawalId] = useState<string | null>(null)
  const [roleDialogUser, setRoleDialogUser] = useState<AdminUser | null>(null)
  const [selectedPermissions, setSelectedPermissions] = useState<AdminPermission>(DEFAULT_PERMISSIONS)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  // Delete user dialog state
  const [deleteDialogUser, setDeleteDialogUser] = useState<AdminUser | null>(null)
  const [deleteStep, setDeleteStep] = useState<'confirm' | 'otp' | 'password'>('confirm')
  const [deleteOtp, setDeleteOtp] = useState('')
  const [deletePassword, setDeletePassword] = useState('')
  const [deleteLoading, setDeleteLoading] = useState(false)
  const [copiedWithdrawalId, setCopiedWithdrawalId] = useState<string | null>(null)
  const [copiedField, setCopiedField] = useState<string | null>(null)
  // Rejection reason dialog (withdrawals)
  const [rejectDialog, setRejectDialog] = useState<{ withdrawalId: string; amount: number } | null>(null)
  const [rejectReason, setRejectReason] = useState('')
  const [rejectLoading, setRejectLoading] = useState(false)
  // Deposit confirmation dialog (confirm with PIN)
  const [depositConfirmDialog, setDepositConfirmDialog] = useState<{ depositId: string; amount: number; fee: number; netAmount: number; userEmail: string; userName: string } | null>(null)
  const [depositConfirmPin, setDepositConfirmPin] = useState('')
  const [depositConfirmLoading, setDepositConfirmLoading] = useState(false)
  // Deposit rejection dialog
  const [depositRejectDialog, setDepositRejectDialog] = useState<{ depositId: string; amount: number; userEmail: string } | null>(null)
  const [depositRejectReason, setDepositRejectReason] = useState('')
  const [depositRejectLoading, setDepositRejectLoading] = useState(false)
  // KYC rejection dialog
  const [kycRejectDialog, setKycRejectDialog] = useState<{ recordId: string; userId: string } | null>(null)
  const [kycRejectReason, setKycRejectReason] = useState('')
  const [kycRejectLoading, setKycRejectLoading] = useState(false)
  // KYC detail modal
  const [kycDetailUser, setKycDetailUser] = useState<string | null>(null)
  // Device management dialog state
  const [deviceDialogUser, setDeviceDialogUser] = useState<AdminUser | null>(null)
  const [deviceList, setDeviceList] = useState<any[]>([])
  const [pendingDevice, setPendingDevice] = useState<any>(null)
  const [deviceLoading, setDeviceLoading] = useState(false)
  // Withdrawal payment proof upload
  const [proofDialogWithdrawal, setProofDialogWithdrawal] = useState<AdminWithdrawal | null>(null)
  const proofInputRef = useRef<HTMLInputElement>(null)
  const [proofLoading, setProofLoading] = useState(false)
  // Full image preview
  const [previewImage, setPreviewImage] = useState<string | null>(null)
  // More tabs dropdown
  const [showMoreMenu, setShowMoreMenu] = useState(false)
  const [menuPosition, setMenuPosition] = useState({ top: 0, left: 0 })
  const moreMenuRef = useRef<HTMLButtonElement>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)
  // Stats state
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [statsLoading, setStatsLoading] = useState(false)
  // Balance adjustment dialog state
  const [balanceDialogUser, setBalanceDialogUser] = useState<AdminUser | null>(null)
  const [balanceAmount, setBalanceAmount] = useState('')
  const [balanceAction, setBalanceAction] = useState<'add' | 'withdraw'>('add')
  const [balanceLoading, setBalanceLoading] = useState(false)
  // Remove merchant dialog state
  const [removeMerchantDialogUser, setRemoveMerchantDialogUser] = useState<AdminUser | null>(null)
  const [removeMerchantLoading, setRemoveMerchantLoading] = useState(false)
  // Reset KYC dialog state
  const [resetKycDialogUser, setResetKycDialogUser] = useState<AdminUser | null>(null)
  const [resetKycLoading, setResetKycLoading] = useState(false)
  // PIN reset requests state
  const [pinResetRequests, setPinResetRequests] = useState<any[]>([])

  // Close dropdown when clicking outside (button or dropdown)
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as Node
      const clickedOnButton = moreMenuRef.current?.contains(target)
      const clickedOnDropdown = dropdownRef.current?.contains(target)
      if (!clickedOnButton && !clickedOnDropdown) {
        setShowMoreMenu(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])



  const openMoreMenu = () => {
    if (moreMenuRef.current) {
      const rect = moreMenuRef.current.getBoundingClientRect()
      // Align dropdown's left edge with button's left edge (RTL: button is on the left)
      setMenuPosition({ top: rect.bottom + 8, left: rect.left })
    }
    setShowMoreMenu(true)
  }

  // Track which tabs have been loaded to avoid re-fetching
  const [loadedTabs, setLoadedTabs] = useState<Set<string>>(new Set())

  // Fetch data when switching tabs (lazy load)
  useEffect(() => {
    if (user?.role === 'admin' || (user?.permissions && Object.values(user.permissions).some(v => v))) {
      if (!loadedTabs.has(activeTab) && activeTab !== 'users') {
        fetchTabData(activeTab)
        setLoadedTabs(prev => new Set(prev).add(activeTab))
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab])

  // Initial load: fetch stats + users tab data
  useEffect(() => {
    if (user?.role === 'admin' || (user?.permissions && Object.values(user.permissions).some(v => v))) {
      const initLoad = async () => {
        setLoading(true)
        try {
          await Promise.all([fetchStats(), fetchUsers(), fetchPinResetRequests()])
        } finally {
          setLoading(false)
        }
      }
      initLoad()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const fetchUsers = async () => {
    try {
      const res = await apiFetch('/api/admin/users')
      const data = await res.json()
      if (data.success) setUsers(data.users || [])
    } catch { /* silent */ }
  }

  const fetchPinResetRequests = async () => {
    try {
      const res = await apiFetch('/api/auth/request-pin-reset')
      const data = await res.json()
      if (data.success) setPinResetRequests(data.requests || [])
    } catch { /* silent */ }
  }

  const fetchDeposits = async () => {
    try {
      const res = await apiFetch(`/api/admin/deposits?_t=${Date.now()}`, { cache: 'no-store' })
      const data = await res.json()
      if (data.success) setDeposits(data.deposits || [])
    } catch { /* silent */ }
  }

  const fetchWithdrawals = async () => {
    try {
      const res = await apiFetch(`/api/admin/withdrawals?_t=${Date.now()}`, { cache: 'no-store' })
      const data = await res.json()
      if (data.success) setWithdrawals(data.withdrawals || [])
    } catch { /* silent */ }
  }

  const fetchKYC = async () => {
    try {
      const res = await apiFetch(`/api/admin/kyc?_t=${Date.now()}`, { cache: 'no-store' })
      const data = await res.json()
      if (data.success) setKycRecords(data.kycRecords || [])
    } catch { /* silent */ }
  }

  const fetchPaymentMethods = async () => {
    try {
      const res = await apiFetch('/api/admin/payment-methods')
      const data = await res.json()
      if (data.success) setPaymentMethods(data.methods || [])
    } catch { /* silent */ }
  }

  const fetchAdminSettings = async () => {
    try {
      const res = await apiFetch(`/api/admin/settings?userId=${user.id}`)
      const data = await res.json()
      if (data.success) setAdminSettings(data.settings)
    } catch { /* silent */ }
  }

  const fetchFees = async () => {
    try {
      const res = await apiFetch('/api/settings?t=' + Date.now(), { cache: 'no-store' })
      const data = await res.json()
      return data.settings || {}
    } catch { return {} }
  }

  const fetchStats = async () => {
    setStatsLoading(true)
    try {
      const res = await apiFetch(`/api/admin/stats?_t=${Date.now()}`, { cache: 'no-store' })
      const data = await res.json()
      if (data.success) setStats(data.stats)
    } catch { /* silent */ }
    finally { setStatsLoading(false) }
  }

  const fetchTabData = (tab: string) => {
    switch (tab) {
      case 'dashboard': fetchStats(); break
      case 'deposits': fetchDeposits(); break
      case 'withdrawals': fetchWithdrawals(); break
      case 'kyc': fetchKYC(); break
      case 'payment-methods': fetchPaymentMethods(); break
      case 'admin-settings': fetchAdminSettings(); break
    }
  }

  // Lightweight refresh: only re-fetch the affected tab
  const refreshCurrentTab = () => {
    fetchTabData(activeTab)
  }

  // Refresh a specific tab without loading spinner
  const refreshTab = (tab: string) => {
    fetchTabData(tab)
  }

  const handleUpdateDeposit = async (depositId: string, status: string) => {
    setActionLoading(depositId)
    try {
      const res = await apiFetch('/api/admin/deposits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ depositId, status }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(
          status === 'confirmed' ? 'تم تأكيد الإيداع' :
          status === 'reviewing' ? 'تم تحويل للمراجعة' :
          'تم رفض الإيداع'
        )
        fetchDeposits(); fetchUsers(); fetchStats()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في تحديث الإيداع')
    } finally {
      setActionLoading(null)
    }
  }

  // Reject deposit with reason
  const handleRejectDeposit = async () => {
    if (!depositRejectDialog || !depositRejectReason.trim()) return
    setDepositRejectLoading(true)
    try {
      const res = await apiFetch('/api/admin/deposits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          depositId: depositRejectDialog.depositId,
          status: 'rejected',
          adminNote: depositRejectReason.trim(),
        }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم رفض الإيداع')
        fetchDeposits(); fetchUsers(); fetchStats()
        setDepositRejectDialog(null)
        setDepositRejectReason('')
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في رفض الإيداع')
    } finally {
      setDepositRejectLoading(false)
    }
  }

  // Confirm deposit with PIN
  const handleConfirmDeposit = async () => {
    if (!depositConfirmDialog || depositConfirmPin.length < 4) return
    setDepositConfirmLoading(true)
    try {
      // First verify admin PIN
      const pinRes = await apiFetch('/api/auth/verify-pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user?.id, pin: depositConfirmPin }),
      })
      const pinData = await pinRes.json()
      if (!pinData.success) {
        toast.error(pinData.message || 'رمز PIN غير صحيح')
        setDepositConfirmLoading(false)
        return
      }
      // PIN verified, proceed with confirmation
      const res = await apiFetch('/api/admin/deposits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ depositId: depositConfirmDialog.depositId, status: 'confirmed' }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم تأكيد الإيداع بنجاح')
        fetchDeposits(); fetchUsers(); fetchStats()
        setDepositConfirmDialog(null)
        setDepositConfirmPin('')
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في تأكيد الإيداع')
    } finally {
      setDepositConfirmLoading(false)
    }
  }

  const handleUpdateWithdrawal = async (withdrawalId: string, status: string, txId?: string) => {
    setActionLoading(withdrawalId)
    try {
      const res = await apiFetch('/api/admin/withdrawals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ withdrawalId, status, txId }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم تحديث السحب')
        fetchWithdrawals(); fetchUsers(); fetchStats()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في تحديث السحب')
    } finally {
      setActionLoading(null)
    }
  }

  const handleUpdateKYC = async (recordId: string, status: string, userId: string, adminNote?: string) => {
    setActionLoading(recordId)
    try {
      const res = await apiFetch('/api/admin/kyc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recordId, status, userId, adminNote }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(status === 'approved' ? 'تم قبول المستند' : 'تم رفض المستند')
        if (kycRejectDialog) setKycRejectDialog(null)
        fetchKYC(); fetchUsers()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في تحديث KYC')
    } finally {
      setActionLoading(null)
    }
  }

  const handleUpdateUser = async (userId: string, updates: Record<string, unknown>) => {
    setActionLoading(userId)
    try {
      const res = await apiFetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, adminId: user?.id, ...updates }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم تحديث المستخدم')
        fetchUsers()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في تحديث المستخدم')
    } finally {
      setActionLoading(null)
    }
  }

  const handleRoleChange = (targetUser: AdminUser, _newRole: string) => {
    setRoleDialogUser(targetUser)
    setSelectedPermissions(DEFAULT_PERMISSIONS)
  }

  const confirmRoleChange = async () => {
    if (!roleDialogUser) return
    setActionLoading(roleDialogUser.id)
    try {
      const res = await apiFetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: roleDialogUser.id, role: roleDialogUser.role === 'admin' ? 'user' : 'admin', permissions: selectedPermissions }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم تحديث صلاحيات المستخدم')
        setRoleDialogUser(null)
        fetchUsers()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في تحديث الصلاحيات')
    } finally {
      setActionLoading(null)
    }
  }

  // ===== DELETE USER HANDLERS =====
  const openDeleteDialog = (targetUser: AdminUser) => {
    setDeleteDialogUser(targetUser)
    setDeleteStep('confirm')
    setDeleteOtp('')
    setDeletePassword('')
  }

  const closeDeleteDialog = () => {
    setDeleteDialogUser(null)
    setDeleteStep('confirm')
    setDeleteOtp('')
    setDeletePassword('')
    setDeleteLoading(false)
  }

  const handleSendDeleteOtp = async () => {
    if (!deleteDialogUser || !user?.id) return
    setDeleteLoading(true)
    try {
      const res = await apiFetch('/api/admin/delete-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminId: user.id, userId: deleteDialogUser.id, step: 'send_otp' }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.message)
        setDeleteStep('otp')
        if (data.debugOtp) {
          toast.info(`رمز التحقق (للتطوير): ${data.debugOtp}`)
        }
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في إرسال رمز التحقق')
    } finally {
      setDeleteLoading(false)
    }
  }

  const handleVerifyDeleteOtp = async () => {
    if (!deleteDialogUser || !user?.id || !deleteOtp) return
    setDeleteLoading(true)
    try {
      const res = await apiFetch('/api/admin/delete-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminId: user.id, userId: deleteDialogUser.id, step: 'verify_otp', otp: deleteOtp }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.message)
        setDeleteStep('password')
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في التحقق')
    } finally {
      setDeleteLoading(false)
    }
  }

  const handleConfirmDelete = async () => {
    if (!deleteDialogUser || !user?.id || !deletePassword) return
    setDeleteLoading(true)
    try {
      const res = await apiFetch('/api/admin/delete-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminId: user.id, userId: deleteDialogUser.id, step: 'confirm_delete', password: deletePassword }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.message)
        closeDeleteDialog()
        fetchUsers()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في حذف المستخدم')
    } finally {
      setDeleteLoading(false)
    }
  }

  const copyWithdrawalAddress = (w: AdminWithdrawal) => {
    navigator.clipboard.writeText(w.toAddress)
    setCopiedWithdrawalId(w.id)
    toast.success('تم النسخ')
    setTimeout(() => setCopiedWithdrawalId(null), 2000)
  }

  const copyField = (key: string, text: string) => {
    navigator.clipboard.writeText(text)
    setCopiedField(key)
    toast.success('تم النسخ')
    setTimeout(() => setCopiedField(null), 2000)
  }

  const openRejectDialog = (w: AdminWithdrawal) => {
    setRejectDialog({ withdrawalId: w.id, amount: w.amount })
    setRejectReason('')
  }

  const handleRejectWithReason = async () => {
    if (!rejectDialog) return
    if (!rejectReason.trim()) { toast.error('يرجى إدخال سبب الرفض'); return }
    setRejectLoading(true)
    try {
      const res = await apiFetch('/api/admin/withdrawals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ withdrawalId: rejectDialog.withdrawalId, status: 'rejected', adminNote: rejectReason.trim() }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم رفض السحب')
        setRejectDialog(null)
        refreshTab('withdrawals')
        fetchUsers()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في رفض السحب')
    } finally {
      setRejectLoading(false)
    }
  }

  // ===== DEVICE MANAGEMENT HANDLERS =====
  const openDeviceDialog = async (targetUser: AdminUser) => {
    setDeviceDialogUser(targetUser)
    setDeviceLoading(true)
    try {
      const res = await apiFetch('/api/admin/devices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminId: user?.id, targetUserId: targetUser.id, action: 'list' }),
      })
      const data = await res.json()
      if (data.success) {
        setDeviceList(data.devices || [])
        setPendingDevice(data.pendingDevice || null)
      } else {
        setDeviceList([])
        setPendingDevice(null)
      }
    } catch {
      setDeviceList([])
      setPendingDevice(null)
    } finally {
      setDeviceLoading(false)
    }
  }

  const handleAuthorizeDevice = async () => {
    if (!deviceDialogUser) return
    setDeviceLoading(true)
    try {
      const res = await apiFetch('/api/admin/devices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          adminId: user?.id,
          targetUserId: deviceDialogUser.id,
          action: 'authorize',
        }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.message)
        setPendingDevice(null)
        openDeviceDialog(deviceDialogUser) // Refresh list
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في التصريح')
    } finally {
      setDeviceLoading(false)
    }
  }

  const handleRemoveAllDevices = async () => {
    if (!deviceDialogUser || !confirm('هل أنت متأكد من إزالة جميع الأجهزة؟')) return
    setDeviceLoading(true)
    try {
      const res = await apiFetch('/api/admin/devices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminId: user?.id, targetUserId: deviceDialogUser.id, action: 'remove_all' }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.message)
        setDeviceList([])
        setPendingDevice(null)
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في إزالة الأجهزة')
    } finally {
      setDeviceLoading(false)
    }
  }

  // ===== WITHDRAWAL PAYMENT PROOF =====
  const openProofDialog = (w: AdminWithdrawal) => {
    setProofDialogWithdrawal(w)
  }

  const handleUploadProof = async () => {
    if (!proofDialogWithdrawal || !proofInputRef.current?.files?.[0]) return
    setProofLoading(true)
    try {
      const file = proofInputRef.current.files[0]
      const compressed = await compressImage(file)
      const screenshotBase64 = await fileToBase64(compressed)

      const res = await apiFetch('/api/admin/withdrawals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          withdrawalId: proofDialogWithdrawal.id,
          status: 'processing',
          screenshot: screenshotBase64,
        }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم رفع إثبات الدفع بنجاح')
        setProofDialogWithdrawal(null)
        refreshTab('withdrawals')
        fetchUsers()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في رفع الصورة')
    } finally {
      setProofLoading(false)
    }
  }

  // ===== BALANCE ADJUSTMENT HANDLER =====
  const handleAdjustBalance = async () => {
    if (!balanceDialogUser || !balanceAmount || parseFloat(balanceAmount) <= 0) {
      toast.error('يرجى إدخال مبلغ صحيح')
      return
    }
    setBalanceLoading(true)
    try {
      const amount = parseFloat(balanceAmount)
      const res = await apiFetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: balanceDialogUser.id,
          balanceAdjustment: balanceAction === 'add' ? amount : -amount,
        }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(balanceAction === 'add' ? `تم إضافة ${amount} USDT` : `تم سحب ${amount} USDT`)
        // If admin adjusted their own balance, update local store
        if (balanceDialogUser?.id === user?.id) {
          useAuthStore.getState().updateBalance(
            balanceAction === 'add'
              ? (user?.balance ?? 0) + amount
              : (user?.balance ?? 0) - amount
          )
        }
        setBalanceDialogUser(null)
        setBalanceAmount('')
        fetchUsers()
        fetchStats()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في تعديل الرصيد')
    } finally {
      setBalanceLoading(false)
    }
  }

  // ===== PIN RESET APPROVAL HANDLER =====
  const handlePinResetAction = async (userId: string, action: 'approve' | 'reject') => {
    setActionLoading(userId)
    try {
      const res = await apiFetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, [action === 'approve' ? 'approvePinReset' : 'rejectPinReset']: true }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(action === 'approve' ? 'تم التصريح بإعادة تعيين PIN' : 'تم رفض الطلب')
        fetchPinResetRequests()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ')
    } finally {
      setActionLoading(null)
    }
  }

  // ===== REMOVE MERCHANT STATUS HANDLER =====
  const handleRemoveMerchant = async () => {
    if (!removeMerchantDialogUser) return
    setRemoveMerchantLoading(true)
    try {
      const res = await apiFetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: removeMerchantDialogUser.id,
          removeMerchant: true,
        }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم إزالة حالة التاجر بنجاح')
        setRemoveMerchantDialogUser(null)
        fetchUsers()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في إزالة حالة التاجر')
    } finally {
      setRemoveMerchantLoading(false)
    }
  }

  // ===== RESET KYC HANDLER =====
  const handleResetKyc = async () => {
    if (!resetKycDialogUser) return
    setResetKycLoading(true)
    try {
      const res = await apiFetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: resetKycDialogUser.id,
          adminId: user?.id,
          resetKyc: true,
        }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم إعادة تعيين التوثيق بنجاح')
        setResetKycDialogUser(null)
        fetchUsers()
        fetchKYC()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في إعادة تعيين التوثيق')
    } finally {
      setResetKycLoading(false)
    }
  }

  // ===== SEND TEMP PIN TO USER/MERCHANT =====
  const handleSendPin = async (userId: string, userEmail: string) => {
    setActionLoading(userId)
    try {
      const res = await apiFetch('/api/admin/send-pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(`تم إرسال رمز PIN إلى ${userEmail}`)
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في إرسال PIN')
    } finally {
      setActionLoading(null)
    }
  }

  // ===== RESET USER PIN (clear so they set new one) =====
  const handleResetUserPin = async (userId: string, userEmail: string) => {
    if (!confirm(`هل أنت متأكد من إعادة تعيين PIN للمستخدم ${userEmail}؟\nسيُطلب من المستخدم إعداد رمز PIN جديد عند تسجيل الدخول.`)) return
    setActionLoading(userId)
    try {
      const res = await apiFetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, resetUserPin: true }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(`تم إعادة تعيين PIN للمستخدم ${userEmail}`)
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في إعادة تعيين PIN')
    } finally {
      setActionLoading(null)
    }
  }

  // ===== ADMIN DISABLE 2FA =====
  const handleAdminDisable2FA = async (targetUser: AdminUser) => {
    if (!confirm(`هل أنت متأكد من تعطيل المصادقة الثنائية للمستخدم ${targetUser.email}؟\nهذا الإجراء لا يمكن التراجع عنه.`)) return
    setActionLoading(targetUser.id)
    try {
      const res = await apiFetch('/api/auth/2fa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id,
          action: 'admin_disable',
          targetUserId: targetUser.id,
          adminToken: useAuthStore.getState().token,
        }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم تعطيل المصادقة الثنائية للمستخدم')
        fetchUsers()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في تعطيل المصادقة الثنائية')
    } finally {
      setActionLoading(null)
    }
  }

  // Determine if user has specific permissions
  const hasPermissions = user?.permissions && Object.keys(user.permissions).length > 0

  const allTabs = [
    { key: 'dashboard' as const, label: 'الإحصائيات', icon: BarChart3, count: stats?.pendingActions || 0 },
    { key: 'users' as const, label: 'المستخدمون', icon: Users, count: users.length },
    { key: 'deposits' as const, label: 'الإيداعات', icon: ArrowDownLeft, count: deposits.filter(d => d.status === 'pending' || d.status === 'reviewing').length },
    { key: 'withdrawals' as const, label: 'السحوبات', icon: ArrowUpRight, count: withdrawals.filter(w => w.status === 'pending' || w.status === 'approved').length },
    { key: 'kyc' as const, label: 'التحقق', icon: Shield, count: kycRecords.filter(k => k.status === 'pending').length },
    { key: 'chats' as const, label: 'المحادثات', icon: MessageCircle, count: chatUnreadCount },
    { key: 'firebase-config' as const, label: 'قاعدة البيانات', icon: Database, count: 0 },
    { key: 'payment-methods' as const, label: 'طرق الدفع', icon: CreditCard, count: paymentMethods.filter(p => p.isActive).length },
    { key: 'referral-settings' as const, label: 'برنامج الدعوات', icon: Gift, count: 0 },
    { key: 'admin-settings' as const, label: 'إعدادات الإدارة', icon: Settings, count: 0 },
    { key: 'faq-bot' as const, label: 'البوت والأسئلة', icon: MessageSquare, count: 0 },
    { key: 'p2p' as const, label: 'P2P والنزاعات', icon: Repeat, count: 0 },
    { key: 'audit-log' as const, label: 'سجل العمليات', icon: Clock, count: 0 },
    { key: 'reports' as const, label: 'التقارير المالية', icon: BarChart3, count: 0 },
    { key: 'system-monitor' as const, label: 'مراقبة النظام', icon: Activity, count: 0 },
    { key: 'admin-team' as const, label: '👥 فريق الإدارة', icon: Users, count: 0 },
    { key: 'admin-financial' as const, label: '💰 الملخص المالي', icon: CreditCard, count: 0 },
    { key: 'banners' as const, label: 'إدارة البانرات', icon: Store, count: 0 },
    { key: 'promo' as const, label: 'أكواد ترويجية', icon: Gift, count: 0 },
    { key: 'super-admin' as const, label: '🛡️ تحكم خارق', icon: Shield, count: 0 },
    { key: 'withdrawal-reports' as const, label: '⚠️ بلاغات السحوبات', icon: AlertTriangle, count: 0 },
  ]

  // Split into main tabs (7) and more tabs
  const MAIN_TABS_COUNT = 7
  const mainTabs = allTabs.slice(0, MAIN_TABS_COUNT)
  const moreTabs = allTabs.slice(MAIN_TABS_COUNT)

  const allowedTabKeys = allTabs.map(t => t.key)
  const effectiveActiveTab = allowedTabKeys.includes(activeTab) ? activeTab : allowedTabKeys[0] || 'dashboard'

  // NEVER show admin accounts in users list — admin is not a user
  const filteredUsers = users
    .filter(u => {
      if (u.role === 'admin') return false
      return true
    })
    .filter(u =>
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.fullName?.includes(searchQuery) ||
      u.phone?.includes(searchQuery) ||
      u.id.includes(searchQuery)
    )

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  const canAccess = user?.role === 'admin' || (user?.permissions && Object.values(user.permissions).some(v => v))

  const DEPOSIT_STATUS_MAP: Record<string, { label: string; color: string }> = {
    pending: { label: 'تم استلام طلبك', color: 'text-yellow-400 bg-yellow-500/10' },
    reviewing: { label: 'طلبك قيد المراجعة', color: 'text-blue-400 bg-blue-500/10' },
    confirmed: { label: 'تم التأكيد', color: 'text-green-400 bg-green-500/10' },
    rejected: { label: 'مرفوض', color: 'text-red-400 bg-red-500/10' },
  }

  const WITHDRAWAL_STATUS_MAP: Record<string, { label: string; color: string }> = {
    pending: { label: 'معلق', color: 'text-yellow-400 bg-yellow-500/10' },
    approved: { label: 'تم قبول السحب - قيد المراجعة', color: 'text-blue-400 bg-blue-500/10' },
    processing: { label: 'تم السحب - بانتظار التأكيد', color: 'text-blue-400 bg-blue-500/10' },
    completed: { label: 'مكتمل', color: 'text-green-400 bg-green-500/10' },
    rejected: { label: 'مرفوض', color: 'text-red-400 bg-red-500/10' },
  }

  if (!canAccess) {
    return (
      <div className="glass-card p-8 text-center">
        <Shield className="w-12 h-12 text-muted-foreground/20 mx-auto mb-3" />
        <p className="text-muted-foreground">ليس لديك صلاحية الوصول</p>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in pb-24">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold gold-text">لوحة الإدارة</h1>
          <p className="text-sm text-muted-foreground">إدارة المستخدمين والعمليات</p>
        </div>
        <div className="flex items-center gap-2">
          {stats?.pendingActions ? (
            <button
              onClick={() => {
                // Navigate to the tab with most pending items
                const depPending = (stats.depositsPending || 0) + (stats.depositsReviewing || 0)
                const witPending = (stats.withdrawalsPending || 0) + (stats.withdrawalsApproved || 0)
                const kycPending = stats.kycRecordsPending || 0
                if (depPending >= witPending && depPending >= kycPending) setActiveTab('deposits')
                else if (witPending >= kycPending) setActiveTab('withdrawals')
                else setActiveTab('kyc')
              }}
              className="glass-card px-3 py-2 flex items-center gap-2 text-xs cursor-pointer hover:bg-white/10 transition-colors"
            >
              <Activity className="w-4 h-4 text-yellow-400" />
              <span className="text-yellow-400 font-bold">{stats.pendingActions} إجراء معلق</span>
              <span className="text-muted-foreground hidden sm:inline">({(stats.depositsPending || 0) + (stats.depositsReviewing || 0)} إيداع، {(stats.withdrawalsPending || 0) + (stats.withdrawalsApproved || 0)} سحب، {stats.kycRecordsPending || 0} توثيق)</span>
            </button>
          ) : null}
          <button
            onClick={() => setActiveTab('users')}
            className="glass-card px-3 py-2 flex items-center gap-2 text-xs cursor-pointer hover:bg-white/10 transition-colors"
          >
            <Users className="w-4 h-4 text-gold" />
            <span>{stats?.totalUsers ?? users.length} مستخدم</span>
          </button>
        </div>
      </div>

      {/* Main tabs (scrollable) + More dropdown (always visible) */}
      <div className="flex gap-2 pb-2 items-center">
        <div className="flex gap-2 overflow-x-auto scrollbar-none flex-1 min-w-0">
          {mainTabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-xs transition-all relative whitespace-nowrap flex-shrink-0 ${
                effectiveActiveTab === tab.key
                  ? 'bg-gold/10 text-gold border border-gold/20'
                  : 'text-muted-foreground hover:text-foreground hover:bg-white/5 border border-transparent'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
              {tab.count > 0 && (
                <span className="w-5 h-5 bg-gold text-gray-900 text-[10px] font-bold rounded-full flex items-center justify-center">
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* المزيد button — always visible */}
        <button
          ref={moreMenuRef}
          onClick={openMoreMenu}
          className={`flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-xs transition-all whitespace-nowrap flex-shrink-0 ${
            showMoreMenu
              ? 'bg-gold/10 text-gold border border-gold/20'
              : 'text-muted-foreground hover:text-foreground hover:bg-white/5 border border-transparent'
          }`}
        >
          المزيد
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showMoreMenu ? 'rotate-180' : ''}`} />
        </button>

        {/* Dropdown rendered via Portal to avoid overflow clipping */}
        {showMoreMenu && (
          <Portal>
            <div
              ref={dropdownRef}
              dir="rtl"
              className="fixed glass-card rounded-xl border border-white/10 py-2 z-[9999] max-h-[70vh] overflow-y-auto shadow-2xl"
              style={{ top: menuPosition.top, left: `${menuPosition.left}px`, right: '8px' }}
            >
              {moreTabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => { setActiveTab(tab.key); setShowMoreMenu(false) }}
                  className={`flex items-center gap-2.5 px-4 py-2.5 text-xs w-full text-right transition-colors ${
                    effectiveActiveTab === tab.key
                      ? 'text-gold bg-gold/5'
                      : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
                  }`}
                >
                  <tab.icon className="w-4 h-4 flex-shrink-0" />
                  <span className="flex-1">{tab.label}</span>
                  {tab.count > 0 && (
                    <span className="w-5 h-5 bg-gold text-gray-900 text-[10px] font-bold rounded-full flex items-center justify-center flex-shrink-0">
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </Portal>
        )}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
          ))}
        </div>
      ) : (
        <div>
          {/* ===================== DASHBOARD / STATS TAB ===================== */}
          {effectiveActiveTab === 'dashboard' && (
            <div className="space-y-4">
              {statsLoading ? (
                <div className="space-y-3">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="glass-card p-4 shimmer h-28 rounded-xl" />
                  ))}
                </div>
              ) : stats ? (
                <div className="space-y-4">
                  {/* Pending Actions Banner */}
                  {stats.pendingActions > 0 && (
                    <div className="glass-card p-4 rounded-xl border border-gold/20 bg-gold/5 space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-gold/10 flex items-center justify-center flex-shrink-0">
                          <AlertTriangle className="w-5 h-5 text-gold" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gold">{stats.pendingActions} إجراء معلق</p>
                          <p className="text-xs text-muted-foreground">طلبات تحتاج مراجعتك</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {/* Pending Deposits */}
                        {(stats.depositsPending + stats.depositsReviewing) > 0 && (
                          <button
                            onClick={() => setActiveTab('deposits')}
                            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-green-500/10 border border-green-500/20 hover:bg-green-500/20 transition-colors"
                          >
                            <ArrowDownLeft className="w-3.5 h-3.5 text-green-400" />
                            <span className="text-xs font-medium text-green-400">{stats.depositsPending + stats.depositsReviewing} إيداع معلق</span>
                          </button>
                        )}
                        {/* Pending Withdrawals */}
                        {(stats.withdrawalsPending + stats.withdrawalsApproved) > 0 && (
                          <button
                            onClick={() => setActiveTab('withdrawals')}
                            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 transition-colors"
                          >
                            <ArrowUpRight className="w-3.5 h-3.5 text-red-400" />
                            <span className="text-xs font-medium text-red-400">{stats.withdrawalsPending + stats.withdrawalsApproved} سحب معلق</span>
                          </button>
                        )}
                        {/* Pending KYC */}
                        {stats.kycRecordsPending > 0 && (
                          <button
                            onClick={() => setActiveTab('kyc')}
                            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-500/10 border border-blue-500/20 hover:bg-blue-500/20 transition-colors"
                          >
                            <BadgeCheck className="w-3.5 h-3.5 text-blue-400" />
                            <span className="text-xs font-medium text-blue-400">{stats.kycRecordsPending} توثيق معلق</span>
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Summary Cards */}
                  <div className="grid grid-cols-2 gap-3">
                    {/* Users Card */}
                    <div onClick={() => setActiveTab('users')} className="glass-card p-4 rounded-xl cursor-pointer hover:bg-white/[0.04] transition-colors">
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="w-4 h-4 text-blue-400" />
                        <span className="text-xs text-muted-foreground">إجمالي المستخدمين</span>
                      </div>
                      <p className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</p>
                      <div className="flex gap-2 mt-1">
                        <span className="text-[10px] text-green-400">+{stats.newUsersToday} اليوم</span>
                        <span className="text-[10px] text-blue-400">+{stats.newUsersThisWeek} الأسبوع</span>
                      </div>
                      <div className="flex gap-3 mt-2 text-[10px]">
                        <span className="text-green-400">نشط: {stats.activeUsers}</span>
                        {(stats.registeredUsers ?? 0) > 0 && <span className="text-yellow-400">مسجل: {stats.registeredUsers}</span>}
                        <span className="text-red-400">معلق: {stats.suspendedUsers}</span>
                      </div>
                    </div>

                    {/* Deposits Card */}
                    <div onClick={() => setActiveTab('deposits')} className="glass-card p-4 rounded-xl cursor-pointer hover:bg-white/[0.04] transition-colors">
                      <div className="flex items-center gap-2 mb-2">
                        <ArrowDownLeft className="w-4 h-4 text-green-400" />
                        <span className="text-xs text-muted-foreground">الإيداعات</span>
                      </div>
                      <p className="text-2xl font-bold text-green-400">{stats.totalDepositsAmount.toLocaleString()}</p>
                      <span className="text-[10px] text-muted-foreground">USDT إجمالي المبالغ المؤكدة</span>
                      <span className="block text-[10px] text-muted-foreground/70 mt-0.5">≈ {formatYER(convertUSDTtoYER(stats.totalDepositsAmount))}</span>
                      <div className="flex gap-3 mt-2 text-[10px]">
                        <span className="text-yellow-400">معلق: {stats.depositsPending}</span>
                        <span className="text-green-400">مؤكد: {stats.depositsConfirmed}</span>
                      </div>
                    </div>

                    {/* Withdrawals Card */}
                    <div onClick={() => setActiveTab('withdrawals')} className="glass-card p-4 rounded-xl cursor-pointer hover:bg-white/[0.04] transition-colors">
                      <div className="flex items-center gap-2 mb-2">
                        <ArrowUpRight className="w-4 h-4 text-red-400" />
                        <span className="text-xs text-muted-foreground">السحوبات</span>
                      </div>
                      <p className="text-2xl font-bold text-red-400">{stats.totalWithdrawalsAmount.toLocaleString()}</p>
                      <span className="text-[10px] text-muted-foreground">USDT إجمالي المبالغ المحولة</span>
                      <span className="block text-[10px] text-muted-foreground/70 mt-0.5">≈ {formatYER(convertUSDTtoYER(stats.totalWithdrawalsAmount))}</span>
                      <div className="flex gap-3 mt-2 text-[10px]">
                        <span className="text-yellow-400">معلق: {stats.withdrawalsPending}</span>
                        <span className="text-blue-400">قيد التنفيذ: {stats.withdrawalsApproved + stats.withdrawalsProcessing}</span>
                        <span className="text-green-400">مكتمل: {stats.withdrawalsCompleted || 0}</span>
                      </div>
                    </div>

                    {/* Fees & Balance Card */}
                    <div className="glass-card p-4 rounded-xl">
                      <div className="flex items-center gap-2 mb-2">
                        <Wallet className="w-4 h-4 text-gold" />
                        <span className="text-xs text-muted-foreground">الإيرادات والرصيد</span>
                      </div>
                      <p className="text-lg font-bold text-gold">{stats.totalFees.toLocaleString()} <span className="text-xs">USDT رسوم</span></p>
                      <span className="text-[10px] text-muted-foreground/70">≈ {formatYER(convertUSDTtoYER(stats.totalFees))}</span>
                      <p className="text-sm font-medium mt-1">{stats.adminBalance.toLocaleString()} <span className="text-xs text-muted-foreground">USDT رصيد الإدارة</span></p>
                      <span className="text-[10px] text-muted-foreground/70">≈ {formatYER(convertUSDTtoYER(stats.adminBalance))}</span>
                    </div>
                  </div>

                  {/* KYC Stats */}
                  <div className="glass-card p-4 rounded-xl">
                    <div className="flex items-center gap-2 mb-3">
                      <Shield className="w-4 h-4 text-purple-400" />
                      <span className="text-sm font-bold">التوثيق (KYC)</span>
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="text-center">
                        <p className="text-xl font-bold text-yellow-400">{stats.kycPending + stats.kycRecordsPending}</p>
                        <p className="text-[10px] text-muted-foreground">معلق</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xl font-bold text-green-400">{stats.kycApproved}</p>
                        <p className="text-[10px] text-muted-foreground">مقبول</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xl font-bold text-red-400">{stats.kycRejected}</p>
                        <p className="text-[10px] text-muted-foreground">مرفوض</p>
                      </div>
                    </div>
                  </div>

                  {/* Today's Summary */}
                  <div className="glass-card p-4 rounded-xl">
                    <div className="flex items-center gap-2 mb-3">
                      <TrendingUp className="w-4 h-4 text-gold" />
                      <span className="text-sm font-bold">ملخص اليوم</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="flex items-center justify-between bg-green-500/5 rounded-lg p-3">
                        <div>
                          <p className="text-xs text-muted-foreground">إيداعات اليوم</p>
                          <p className="text-lg font-bold text-green-400">{stats.depositsTodayAmount.toLocaleString()} USDT</p>
                        </div>
                        <span className="text-2xl font-bold text-green-400/30">{stats.depositsTodayCount}</span>
                      </div>
                      <div className="flex items-center justify-between bg-red-500/5 rounded-lg p-3">
                        <div>
                          <p className="text-xs text-muted-foreground">سحوبات اليوم</p>
                          <p className="text-lg font-bold text-red-400">{stats.withdrawalsTodayAmount.toLocaleString()} USDT</p>
                        </div>
                        <span className="text-2xl font-bold text-red-400/30">{stats.withdrawalsTodayCount}</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 mt-3">
                      <div className="text-center bg-blue-500/5 rounded-lg p-2">
                        <p className="text-xs text-muted-foreground">إيداعات الأسبوع</p>
                        <p className="text-sm font-bold">{stats.depositsThisWeekAmount.toLocaleString()} USDT</p>
                      </div>
                      <div className="text-center bg-purple-500/5 rounded-lg p-2">
                        <p className="text-xs text-muted-foreground">إيداعات الشهر</p>
                        <p className="text-sm font-bold">{stats.depositsThisMonthAmount.toLocaleString()} USDT</p>
                      </div>
                    </div>
                  </div>

                  {/* Recent Activity */}
                  {stats.recentActivity && stats.recentActivity.length > 0 && (
                    <div className="glass-card p-4 rounded-xl">
                      <div className="flex items-center gap-2 mb-3">
                        <Clock className="w-4 h-4 text-gold" />
                        <span className="text-sm font-bold">أحدث العمليات</span>
                      </div>
                      <div className="space-y-2">
                        {stats.recentActivity.map((item: any, idx: number) => (
                          <div key={idx} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                            <div className="flex items-center gap-2">
                              {item.type === 'deposit' ? (
                                <ArrowDownCircle className="w-4 h-4 text-green-400" />
                              ) : (
                                <ArrowUpCircle className="w-4 h-4 text-red-400" />
                              )}
                              <div>
                                <p className="text-xs font-medium">{item.type === 'deposit' ? 'إيداع' : 'سحب'}</p>
                                <p className="text-[10px] text-muted-foreground">
                                  {item.createdAt ? new Date(item.createdAt).toLocaleDateString('ar-SA') : ''}
                                </p>
                              </div>
                            </div>
                            <div className="text-left">
                              <p className="text-sm font-bold">{(item.amount || 0).toLocaleString()} USDT</p>
                              <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                                item.status === 'confirmed' || item.status === 'completed' ? 'bg-green-500/10 text-green-400' :
                                item.status === 'processing' ? 'bg-blue-500/10 text-blue-400' :
                                item.status === 'approved' ? 'bg-blue-500/10 text-blue-400' :
                                item.status === 'pending' ? 'bg-yellow-500/10 text-yellow-400' :
                                item.status === 'reviewing' ? 'bg-blue-500/10 text-blue-400' :
                                'bg-red-500/10 text-red-400'
                              }`}>
                                {item.status === 'confirmed' ? 'مؤكد' :
                                 item.status === 'completed' ? 'مكتمل' :
                                 item.status === 'processing' ? 'بانتظار التأكيد' :
                                 item.status === 'approved' ? 'مقبول' :
                                 item.status === 'pending' ? 'معلق' :
                                 item.status === 'reviewing' ? 'قيد المراجعة' : 'مرفوض'}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="glass-card p-8 text-center text-muted-foreground text-sm">
                  تعذر تحميل الإحصائيات
                </div>
              )}
            </div>
          )}

          {/* ===================== USERS TAB ===================== */}
          {effectiveActiveTab === 'users' && (
            <div className="space-y-3">
              {/* PIN Reset Requests Banner */}
              {pinResetRequests.length > 0 && (
                <div className="glass-card p-4 rounded-xl border border-orange-500/20 bg-orange-500/5">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-orange-400" />
                      <span className="text-sm font-bold text-orange-400">طلبات إعادة تعيين PIN ({pinResetRequests.length})</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {pinResetRequests.slice(0, 5).map((req: any) => (
                      <div key={req.userId} className="flex items-center justify-between p-2.5 rounded-lg bg-white/5">
                        <div>
                          <p className="text-xs font-medium">{req.userFullName || req.userEmail}</p>
                          <p className="text-[10px] text-muted-foreground">{new Date(req.requestedAt).toLocaleString('ar-SA')}</p>
                        </div>
                        <div className="flex gap-1">
                          <button
                            onClick={() => handlePinResetAction(req.userId, 'approve')}
                            disabled={actionLoading === req.userId}
                            className="text-[10px] px-2 py-1.5 rounded-md bg-green-500/10 text-green-400 hover:bg-green-500/20"
                          >
                            تصريح
                          </button>
                          <button
                            onClick={() => handlePinResetAction(req.userId, 'reject')}
                            disabled={actionLoading === req.userId}
                            className="text-[10px] px-2 py-1.5 rounded-md bg-red-500/10 text-red-400 hover:bg-red-500/20"
                          >
                            رفض
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="بحث بالبريد أو الاسم أو الهاتف..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="glass-input h-10 pr-10 text-sm"
                />
              </div>

              {filteredUsers.length === 0 ? (
                <div className="glass-card p-8 text-center text-muted-foreground text-sm">
                  لا يوجد مستخدمون
                </div>
              ) : (
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {filteredUsers.map((u) => (
                    <div key={u.id} className="glass-card rounded-xl overflow-hidden">
                      <div
                        className="p-3 flex items-center justify-between cursor-pointer hover:bg-white/5 transition-colors"
                        onClick={() => setExpandedUserId(expandedUserId === u.id ? null : u.id)}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold ${
                            u.status === 'active' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
                          }`}>
                            {(u.fullName || u.email).charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="text-sm font-medium">{u.fullName || 'بدون اسم'}</p>
                            <p className="text-xs text-muted-foreground flex items-center gap-1" dir="ltr">
                              <Mail className="w-3 h-3" /> {u.email}
                            </p>
                            {u.merchantId && (
                              <span className="text-[9px] px-1.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 font-medium flex items-center gap-0.5">
                                <Store className="w-2.5 h-2.5" />
                                تاجر
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] px-2 py-1 rounded-md font-medium ${
                            u.status === 'active' ? 'bg-green-500/10 text-green-400' :
                            u.status === 'registered' ? 'bg-yellow-500/10 text-yellow-400' :
                            u.status === 'locked_device' ? 'bg-red-500/10 text-red-400' :
                            'bg-red-500/10 text-red-400'
                          }`}>
                            {u.status === 'active' ? 'نشط' : u.status === 'registered' ? 'مسجل' : u.status === 'locked_device' ? '🔒 مقفل' : 'معلق'}
                          </span>
                          {expandedUserId === u.id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                        </div>
                      </div>

                      {expandedUserId === u.id && (
                        <div className="border-t border-white/5 p-4 space-y-4 animate-fade-in">
                          <div className="grid grid-cols-2 gap-3">
                            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5">
                              <Mail className={`w-4 h-4 ${u.emailVerified ? 'text-green-400' : 'text-muted-foreground'}`} />
                              <div>
                                <p className="text-[10px] text-muted-foreground">البريد</p>
                                <p className="text-xs font-medium">{u.emailVerified ? 'متحقق ✓' : 'غير متحقق'}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5">
                              <Phone className={`w-4 h-4 ${u.phoneVerified ? 'text-green-400' : u.phone ? 'text-yellow-400' : 'text-muted-foreground'}`} />
                              <div>
                                <p className="text-[10px] text-muted-foreground">الهاتف</p>
                                <p className="text-xs font-medium">{u.phone ? (u.phoneVerified ? '+967 ' + u.phone + ' ✓' : '+967 ' + u.phone) : 'غير محدد'}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5">
                              <DollarSign className="w-4 h-4 text-gold" />
                              <div>
                                <p className="text-[10px] text-muted-foreground">الرصيد</p>
                                <p className="text-xs font-bold gold-text">{(u.balance ?? 0).toFixed(2)} USDT</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5">
                              <Hash className="w-4 h-4 text-blue-400" />
                              <div>
                                <p className="text-[10px] text-muted-foreground">رقم الحساب</p>
                                <p className="text-xs font-medium font-mono">{u.accountNumber || 'غير محدد'}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-white/5">
                              <BadgeCheck className={`w-4 h-4 ${
                                u.kycStatus === 'approved' ? 'text-green-400' :
                                u.kycStatus === 'pending' ? 'text-yellow-400' :
                                u.kycStatus === 'rejected' ? 'text-red-400' : 'text-muted-foreground'
                              }`} />
                              <div>
                                <p className="text-[10px] text-muted-foreground">الهوية (KYC)</p>
                                <p className={`text-xs font-medium ${
                                  u.kycStatus === 'approved' ? 'text-green-400' :
                                  u.kycStatus === 'pending' ? 'text-yellow-400' :
                                  u.kycStatus === 'rejected' ? 'text-red-400' : ''
                                }`}>
                                  {u.kycStatus === 'approved' ? 'مقبول ✓' :
                                   u.kycStatus === 'pending' ? 'قيد المراجعة' :
                                   u.kycStatus === 'rejected' ? 'مرفوض' : 'لا يوجد'}
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-xs text-muted-foreground px-1">
                            <div className="flex items-center gap-2">
                              <Star className="w-3.5 h-3.5" />
                              <span>الدور: <strong className="text-foreground">{ROLE_LABELS[u.role] || u.role}</strong></span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="w-3.5 h-3.5" />
                              <span>تاريخ التسجيل: {formatDate(u.createdAt)}</span>
                            </div>
                          </div>

                          {/* Action buttons: main admin sees all, sub-admin sees limited */}
                          <div className="grid grid-cols-3 gap-2 pt-2">
                            {/* Suspend / Activate */}
                            {u.status === 'active' ? (
                              <button
                                onClick={() => handleUpdateUser(u.id, { status: 'suspended' })}
                                disabled={actionLoading === u.id}
                                className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors font-medium"
                              >
                                {actionLoading === u.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Ban className="w-3.5 h-3.5" />}
                                تعليق
                              </button>
                            ) : (
                              <button
                                onClick={() => handleUpdateUser(u.id, { status: 'active' })}
                                disabled={actionLoading === u.id}
                                className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors font-medium"
                              >
                                {actionLoading === u.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <UserCheck className="w-3.5 h-3.5" />}
                                {u.status === 'locked_device' ? 'فتح' : 'تفعيل'}
                              </button>
                            )}
                            {/* Device management — always visible (needed for locked_device unlock) */}
                            <button
                              onClick={() => openDeviceDialog(u)}
                              className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-purple-500/10 text-purple-400 hover:bg-purple-500/20 transition-colors font-medium"
                            >
                              <Settings className="w-3.5 h-3.5" />
                              الأجهزة
                            </button>
                            {/* Promote / Remove admin */}
                            <button
                              onClick={() => handleRoleChange(u, u.role === 'admin' ? 'user' : 'admin')}
                              disabled={actionLoading === u.id}
                              className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-gold/10 text-gold hover:bg-gold/20 transition-colors font-medium"
                            >
                              {actionLoading === u.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Crown className="w-3.5 h-3.5" />}
                              {u.role === 'admin' ? 'إزالة' : 'ترقية'}
                            </button>
                            {/* Delete */}
                            <button
                              onClick={() => openDeleteDialog(u)}
                              className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-red-600/10 text-red-500 hover:bg-red-600/20 transition-colors font-medium"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              حذف
                            </button>
                            {/* Add balance */}
                            <button
                              onClick={() => { setBalanceDialogUser(u); setBalanceAction('add'); setBalanceAmount('') }}
                              className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors font-medium"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              إضافة رصيد
                            </button>
                            {/* Withdraw balance */}
                            <button
                              onClick={() => { setBalanceDialogUser(u); setBalanceAction('withdraw'); setBalanceAmount('') }}
                              className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-orange-500/10 text-orange-400 hover:bg-orange-500/20 transition-colors font-medium"
                            >
                              <ArrowUpRight className="w-3.5 h-3.5" />
                              سحب رصيد
                            </button>
                            {/* Remove merchant — merchants only */}
                            {u.merchantId && (
                              <button
                                onClick={() => setRemoveMerchantDialogUser(u)}
                                className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-orange-500/10 text-orange-400 hover:bg-orange-500/20 transition-colors font-medium"
                              >
                                <UserX className="w-3.5 h-3.5" />
                                إزالة التاجر
                              </button>
                            )}
                            {/* Reset KYC — users with KYC (approved/rejected/pending) */}
                            {u.kycStatus && u.kycStatus !== 'none' && u.role !== 'admin' && (
                              <button
                                onClick={() => setResetKycDialogUser(u)}
                                className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20 transition-colors font-medium"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                تحديث الهوية
                              </button>
                            )}
                            {/* Send temp PIN — admin only, non-admin users */}
                            {u.role !== 'admin' && (
                              <button
                                onClick={() => handleSendPin(u.id, u.email)}
                                disabled={actionLoading === u.id}
                                className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-colors font-medium"
                              >
                                {actionLoading === u.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <KeyRound className="w-3.5 h-3.5" />}
                                إرسال PIN
                              </button>
                            )}
                            {/* Reset PIN — admin only, non-admin users */}
                            {u.role !== 'admin' && (
                              <button
                                onClick={() => handleResetUserPin(u.id, u.email)}
                                disabled={actionLoading === u.id}
                                className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-orange-500/10 text-orange-400 hover:bg-orange-500/20 transition-colors font-medium"
                              >
                                {actionLoading === u.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
                                إعادة تعيين PIN
                              </button>
                            )}
                            {/* Disable 2FA — only if user has 2FA enabled */}
                            {u.twoFactorEnabled && u.role !== 'admin' && (
                              <button
                                onClick={() => handleAdminDisable2FA(u)}
                                disabled={actionLoading === u.id}
                                className="flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-yellow-500/10 text-yellow-400 hover:bg-yellow-500/20 transition-colors font-medium"
                              >
                                {actionLoading === u.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShieldOff className="w-3.5 h-3.5" />}
                                تعطيل 2FA
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ===================== DEPOSITS TAB ===================== */}
          {effectiveActiveTab === 'deposits' && (
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {deposits.length === 0 ? (
                <div className="glass-card p-8 text-center text-muted-foreground text-sm">لا توجد إيداعات</div>
              ) : (
                deposits.map((d) => {
                  const isTerminal = d.status === 'confirmed' || d.status === 'rejected'
                  const isExpanded = !isTerminal || expandedDepositId === d.id
                  return (
                    <div key={d.id} className={`glass-card rounded-xl overflow-hidden transition-all duration-200 ${isTerminal && !isExpanded ? 'cursor-pointer hover:bg-white/[0.03]' : ''}`}
                      onClick={() => isTerminal && setExpandedDepositId(expandedDepositId === d.id ? null : d.id)}
                    >
                      {/* Compact Header — always visible */}
                      <div className={`flex items-center justify-between ${isExpanded ? 'p-4' : 'p-3'}`}>
                        <div className="flex items-center gap-3">
                          {!isTerminal && (
                            <div className="w-9 h-9 rounded-lg bg-green-500/10 flex items-center justify-center flex-shrink-0">
                              <ArrowDownLeft className="w-4 h-4 text-green-400" />
                            </div>
                          )}
                          {isTerminal && (
                            <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${d.status === 'confirmed' ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                              {d.status === 'confirmed' ? <BadgeCheck className="w-4 h-4 text-green-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                            </div>
                          )}
                          <div>
                            <p className={`font-medium ${isExpanded ? 'text-sm' : 'text-xs'}`}>{d.user.fullName || d.user.email}</p>
                            {!isExpanded && (
                              <p className="text-[10px] text-muted-foreground">{formatDate(d.createdAt)}</p>
                            )}
                            {isExpanded && (
                              <p className="text-xs text-muted-foreground" dir="ltr">{d.txId || d.id.substring(0, 12)}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-left">
                            <p className={`font-bold gold-text ${isExpanded ? 'text-sm' : 'text-xs'}`}>{(d.netAmount ?? d.amount ?? 0).toFixed(2)} USDT</p>
                            {!isExpanded && (
                              <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-medium ${DEPOSIT_STATUS_MAP[d.status]?.color || ''}`}>
                                {DEPOSIT_STATUS_MAP[d.status]?.label || d.status}
                              </span>
                            )}
                            {isExpanded && (
                              <span className={`text-xs px-2 py-0.5 rounded-md font-medium ${DEPOSIT_STATUS_MAP[d.status]?.color || ''}`}>
                                {DEPOSIT_STATUS_MAP[d.status]?.label || d.status}
                              </span>
                            )}
                          </div>
                          {isTerminal && (
                            <div className="flex-shrink-0 ml-1">
                              {expandedDepositId === d.id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Expanded Details — only for terminal statuses when expanded */}
                      {isExpanded && (
                        <div className="space-y-2">
                          {/* Fee breakdown */}
                          {(d.fee ?? 0) > 0 && (
                            <div className="px-4">
                              <div className="p-2 rounded-lg bg-white/5 text-xs space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-muted-foreground">المبلغ المدفوع: <strong className="text-foreground">{(d.amount ?? 0).toFixed(2)} USDT</strong></span>
                                </div>
                                <div className="flex items-center justify-between">
                                  <span className="text-muted-foreground">المبلغ الصافي للمستخدم: <strong className="text-green-400">{(d.netAmount ?? 0).toFixed(2)} USDT</strong></span>
                                  <span className="text-muted-foreground">الرسوم → حساب الإدارة: <strong className="text-gold">{(d.fee ?? 0).toFixed(2)} USDT</strong></span>
                                </div>
                              </div>
                            </div>
                          )}
                          {/* Screenshot */}
                          {d.screenshot && (
                            <div className="px-4 pb-2">
                              <button
                                onClick={(e) => { e.stopPropagation(); setPreviewImage(d.screenshot) }}
                                className="rounded-xl overflow-hidden border border-white/10 block w-full"
                              >
                                <img src={d.screenshot} alt="إثبات الدفع" className="w-full h-32 object-cover" />
                              </button>
                            </div>
                          )}
                          {/* Date for expanded terminal */}
                          {isTerminal && (
                            <div className="px-4 pb-2 text-[10px] text-muted-foreground">{formatDate(d.createdAt)}</div>
                          )}
                          {/* Actions — only for active statuses */}
                          {d.status === 'pending' && (
                            <div className="flex gap-2 px-4 pb-3">
                              <button onClick={(e) => { e.stopPropagation(); handleUpdateDeposit(d.id, 'reviewing') }} disabled={actionLoading === d.id} className="flex-1 flex items-center justify-center gap-1 text-xs py-2 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-colors font-medium">
                                <Eye className="w-3 h-3" /> مراجعة
                              </button>
                            </div>
                          )}
                          {d.status === 'reviewing' && (
                            <div className="flex gap-2 px-4 pb-3">
                              <button onClick={(e) => { e.stopPropagation(); setDepositConfirmDialog({ depositId: d.id, amount: d.amount, fee: d.fee || 0, netAmount: d.netAmount || d.amount, userEmail: d.user.email, userName: d.user.fullName || d.user.email }); setDepositConfirmPin('') }} disabled={actionLoading === d.id} className="flex-1 flex items-center justify-center gap-1 text-xs py-2 rounded-lg bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors font-medium">
                                <Check className="w-3 h-3" /> تأكيد
                              </button>
                              <button onClick={(e) => { e.stopPropagation(); setDepositRejectDialog({ depositId: d.id, amount: d.amount, userEmail: d.user.email }) }} disabled={actionLoading === d.id} className="flex-1 flex items-center justify-center gap-1 text-xs py-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors font-medium">
                                <X className="w-3 h-3" /> رفض
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )
                })
              )}
            </div>
          )}

          {/* ===================== WITHDRAWALS TAB ===================== */}
          {effectiveActiveTab === 'withdrawals' && (
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {withdrawals.length === 0 ? (
                <div className="glass-card p-8 text-center text-muted-foreground text-sm">لا توجد سحوبات</div>
              ) : (
                withdrawals.map((w) => {
                  const isTerminal = w.status === 'processing' || w.status === 'completed' || w.status === 'rejected'
                  const isExpanded = !isTerminal || expandedWithdrawalId === w.id
                  return (
                    <div key={w.id} className={`glass-card rounded-xl overflow-hidden transition-all duration-200 ${isTerminal && !isExpanded ? 'cursor-pointer hover:bg-white/[0.03]' : ''}`}
                      onClick={() => isTerminal && setExpandedWithdrawalId(expandedWithdrawalId === w.id ? null : w.id)}
                    >
                      {/* Compact Header — always visible */}
                      <div className={`flex items-center justify-between ${isExpanded ? 'p-4 border-b border-white/5' : 'p-3'}`}>
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                            !isTerminal ? 'bg-gold/10 gold-text' :
                            w.status === 'completed' ? 'bg-green-500/10 text-green-400' :
                            w.status === 'rejected' ? 'bg-red-500/10 text-red-400' :
                            'bg-blue-500/10 text-blue-400'
                          }`}>
                            {(w.user.fullName || w.user.email).charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className={`font-medium ${isExpanded ? 'text-sm' : 'text-xs'}`}>{w.user.fullName || 'بدون اسم'}</p>
                            {!isExpanded && (
                              <p className="text-[10px] text-muted-foreground">{formatDate(w.createdAt)}</p>
                            )}
                            {isExpanded && (
                              <p className="text-xs text-muted-foreground" dir="ltr">{w.user.email}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-left">
                            <p className={`font-bold gold-text ${isExpanded ? 'text-sm' : 'text-xs'}`}>{(w.amount ?? 0).toFixed(2)} USDT</p>
                            {!isExpanded && (w.fee ?? 0) > 0 && (
                              <p className="text-[10px] text-muted-foreground">صافي: {(w.netAmount ?? (w.amount - w.fee) ?? 0).toFixed(2)}</p>
                            )}
                            {isExpanded && (w.fee ?? 0) > 0 && (
                              <p className="text-[10px] text-muted-foreground">الصافي: {(w.netAmount ?? (w.amount - w.fee) ?? 0).toFixed(2)} USDT</p>
                            )}
                            <span className={`px-2 py-0.5 rounded-md font-medium ${isExpanded ? 'text-xs' : 'text-[10px]'} ${WITHDRAWAL_STATUS_MAP[w.status]?.color || ''}`}>
                              {WITHDRAWAL_STATUS_MAP[w.status]?.label || w.status}
                            </span>
                          </div>
                          {isTerminal && (
                            <div className="flex-shrink-0 ml-1">
                              {expandedWithdrawalId === w.id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Expanded Details */}
                      {isExpanded && (
                        <div className="p-4 space-y-2">
                          <p className="text-xs text-muted-foreground font-medium mb-2">بيانات الساحب:</p>
                          <div className="grid grid-cols-1 gap-1.5">
                            {w.user.fullName && (
                              <div className="flex items-center justify-between p-2 rounded-lg bg-white/5 group">
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="text-[10px] text-muted-foreground flex-shrink-0">الاسم</span>
                                  <span className="text-xs font-medium truncate">{w.user.fullName}</span>
                                </div>
                                <button onClick={(e) => { e.stopPropagation(); copyField(`${w.id}-name`, w.user.fullName!) }} className="text-muted-foreground hover:text-gold transition-colors flex-shrink-0">
                                  {copiedField === `${w.id}-name` ? <CheckIcon className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                                </button>
                              </div>
                            )}
                            {w.user.phone && (
                              <div className="flex items-center justify-between p-2 rounded-lg bg-white/5 group">
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="text-[10px] text-muted-foreground flex-shrink-0">الهاتف</span>
                                  <span className="text-xs font-medium truncate" dir="ltr">{w.user.phone}</span>
                                </div>
                                <button onClick={(e) => { e.stopPropagation(); copyField(`${w.id}-phone`, w.user.phone!) }} className="text-muted-foreground hover:text-gold transition-colors flex-shrink-0">
                                  {copiedField === `${w.id}-phone` ? <CheckIcon className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                                </button>
                              </div>
                            )}
                            <div className="flex items-center justify-between p-2 rounded-lg bg-white/5 group">
                              <div className="flex items-center gap-2 min-w-0">
                                <span className="text-[10px] text-muted-foreground flex-shrink-0">البريد</span>
                                <span className="text-xs font-medium truncate" dir="ltr">{w.user.email}</span>
                              </div>
                              <button onClick={(e) => { e.stopPropagation(); copyField(`${w.id}-email`, w.user.email) }} className="text-muted-foreground hover:text-gold transition-colors flex-shrink-0">
                                {copiedField === `${w.id}-email` ? <CheckIcon className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                          </div>

                          <div className="border-t border-white/5 pt-2 mt-2">
                            <p className="text-xs text-muted-foreground font-medium mb-2">بيانات السحب:</p>
                            <div className="grid grid-cols-1 gap-1.5">
                              <div className="flex items-center justify-between p-2 rounded-lg bg-white/5">
                                <div className="flex items-center gap-2 min-w-0">
                                  <span className="text-[10px] text-muted-foreground flex-shrink-0">الطريقة</span>
                                  <span className="text-xs font-medium truncate">
                                    {w.paymentMethodName
                                      ? (w.network && !w.paymentMethodName.includes(w.network)
                                        ? `${w.paymentMethodName} - ${w.network}`
                                        : w.paymentMethodName)
                                      : (w.method === 'crypto' || w.method === 'blockchain'
                                        ? (w.network ? `عملات رقمية - ${w.network}` : 'عملات رقمية')
                                        : w.method === 'bank_deposit' ? 'إيداع لمحفظة' :
                                          w.method === 'atm_transfer' ? 'تحويل عبر صراف' :
                                            w.method === 'bank_transfer' ? 'تحويل بنكي' : w.method)}
                                  </span>
                                </div>
                              </div>
                              {/* toAddress - parsed structured display */}
                              {(() => {
                                const isCrypto = w.method === 'crypto' || w.method === 'blockchain'
                                if (isCrypto) {
                                  return (
                                    <div className="flex items-center justify-between p-2 rounded-lg bg-white/5 group">
                                      <div className="flex-1 min-w-0">
                                        <span className="text-[10px] text-muted-foreground block mb-0.5">عنوان المحفظة</span>
                                        <p className="text-xs font-medium font-mono" dir="ltr">{w.toAddress}</p>
                                      </div>
                                      <button onClick={(e) => { e.stopPropagation(); copyWithdrawalAddress(w) }} className="text-gold hover:text-gold-light transition-colors flex-shrink-0 mr-2">
                                        {copiedWithdrawalId === w.id ? <CheckIcon className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                      </button>
                                    </div>
                                  )
                                }
                                const isAtm = w.toAddress.startsWith('صراف')
                                const prefix = isAtm ? 'صراف: ' : 'بنكي: '
                                const parts = w.toAddress.replace(prefix, '').split(' - ').filter(Boolean)
                                if (isAtm) {
                                  return (
                                    <div className="space-y-1">
                                      {parts[0] && (
                                        <div className="flex items-center justify-between p-2 rounded-lg bg-white/5 group">
                                          <div className="flex items-center gap-2 min-w-0">
                                            <span className="text-[10px] text-muted-foreground flex-shrink-0">اسم المستلم</span>
                                            <span className="text-xs font-medium truncate">{parts[0]}</span>
                                          </div>
                                          <button onClick={(e) => { e.stopPropagation(); copyField(`${w.id}-recipient`, parts[0]) }} className="text-muted-foreground hover:text-gold transition-colors flex-shrink-0">
                                            {copiedField === `${w.id}-recipient` ? <CheckIcon className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                                          </button>
                                        </div>
                                      )}
                                      {parts[1] && (
                                        <div className="flex items-center justify-between p-2 rounded-lg bg-white/5 group">
                                          <div className="flex items-center gap-2 min-w-0">
                                            <span className="text-[10px] text-muted-foreground flex-shrink-0">رقم الجوال</span>
                                            <span className="text-xs font-medium font-mono truncate" dir="ltr">{parts[1]}</span>
                                          </div>
                                          <button onClick={(e) => { e.stopPropagation(); copyField(`${w.id}-rphone`, parts[1]) }} className="text-muted-foreground hover:text-gold transition-colors flex-shrink-0">
                                            {copiedField === `${w.id}-rphone` ? <CheckIcon className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                                          </button>
                                        </div>
                                      )}
                                      {parts[2] && (
                                        <div className="flex items-center justify-between p-2 rounded-lg bg-white/5">
                                          <div className="flex items-center gap-2">
                                            <span className="text-[10px] text-muted-foreground">الشبكة / البنك</span>
                                            <span className="text-xs font-medium">{parts[2]}</span>
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  )
                                }
                                return (
                                  <div className="space-y-1">
                                    {parts[0] && (
                                      <div className="flex items-center justify-between p-2 rounded-lg bg-white/5 group">
                                        <div className="flex items-center gap-2 min-w-0">
                                          <span className="text-[10px] text-muted-foreground flex-shrink-0">اسم المستفيد</span>
                                          <span className="text-xs font-medium truncate">{parts[0]}</span>
                                        </div>
                                        <button onClick={(e) => { e.stopPropagation(); copyField(`${w.id}-beneficiary`, parts[0]) }} className="text-muted-foreground hover:text-gold transition-colors flex-shrink-0">
                                          {copiedField === `${w.id}-beneficiary` ? <CheckIcon className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                                        </button>
                                      </div>
                                    )}
                                    {parts[1] && (
                                      <div className="flex items-center justify-between p-2 rounded-lg bg-white/5 group">
                                        <div className="flex items-center gap-2 min-w-0">
                                          <span className="text-[10px] text-muted-foreground flex-shrink-0">رقم الحساب</span>
                                          <span className="text-xs font-medium font-mono" dir="ltr">{parts[1]}</span>
                                        </div>
                                        <button onClick={(e) => { e.stopPropagation(); copyField(`${w.id}-account`, parts[1]) }} className="text-muted-foreground hover:text-gold transition-colors flex-shrink-0">
                                          {copiedField === `${w.id}-account` ? <CheckIcon className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                                        </button>
                                      </div>
                                    )}
                                  </div>
                                )
                              })()}
                              <div className="p-2 rounded-lg bg-white/5 text-xs space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-muted-foreground">الرسوم → حساب الإدارة: <strong className="text-gold">{(w.fee ?? 0).toFixed(2)} USDT</strong></span>
                                </div>
                                <div className="flex items-center justify-between">
                                  <span className="text-muted-foreground">الصافي للمستلم: <strong className="text-green-400">{(w.netAmount ?? ((w.amount ?? 0) - (w.fee ?? 0))).toFixed(2)} USDT</strong></span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Payment proof */}
                          {w.screenshot && (
                            <div className="pt-2">
                              <button onClick={(e) => { e.stopPropagation(); setPreviewImage(w.screenshot) }} className="rounded-xl overflow-hidden border border-white/10 block w-full">
                                <img src={w.screenshot} alt="إثبات الدفع" className="w-full h-32 object-cover" />
                              </button>
                            </div>
                          )}

                          {/* Date */}
                          <div className="text-[10px] text-muted-foreground pt-1">{formatDate(w.createdAt)}</div>
                        </div>
                      )}

                      {/* Withdrawal Actions — only for active statuses */}
                      {w.status === 'pending' && (
                        <div className="flex gap-2 p-4 pt-0">
                          <button onClick={(e) => { e.stopPropagation(); handleUpdateWithdrawal(w.id, 'approved') }} disabled={actionLoading === w.id} className="flex-1 flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-colors font-medium">
                            {actionLoading === w.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />} قبول
                          </button>
                          <button onClick={(e) => { e.stopPropagation(); openRejectDialog(w) }} className="flex-1 flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors font-medium">
                            <X className="w-3 h-3" /> رفض
                          </button>
                        </div>
                      )}
                      {w.status === 'approved' && (
                        <div className="flex gap-2 p-4 pt-0">
                          <button onClick={(e) => { e.stopPropagation(); openProofDialog(w) }} className="flex-1 flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-gold/10 text-gold hover:bg-gold/20 transition-colors font-medium">
                            <Upload className="w-3 h-3" /> رفع صورة الدفع
                          </button>
                          <button onClick={(e) => { e.stopPropagation(); openRejectDialog(w) }} className="flex-1 flex items-center justify-center gap-1 text-xs py-2.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors font-medium">
                            <X className="w-3 h-3" /> رفض
                          </button>
                        </div>
                      )}
                    </div>
                  )
                })
              )}
            </div>
          )}

          {/* ===================== PAYMENT METHODS TAB ===================== */}
          {effectiveActiveTab === 'payment-methods' && (
            <PaymentMethodsManager methods={paymentMethods} onRefresh={() => { fetchPaymentMethods() }} />
          )}

          {/* ===================== ADMIN SETTINGS TAB ===================== */}
          {effectiveActiveTab === 'admin-settings' && (
            <AdminSettingsPanel settings={adminSettings} onRefresh={fetchAdminSettings} />
          )}

          {/* ===================== CHATS TAB ===================== */}
          {effectiveActiveTab === 'chats' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
                ))}
              </div>
            }>
              <AdminChat />
            </Suspense>
          )}

          {/* ===================== REFERRAL SETTINGS TAB ===================== */}
          {effectiveActiveTab === 'referral-settings' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
                ))}
              </div>
            }>
              <AdminReferralSettings />
            </Suspense>
          )}

          {/* ===================== FAQ BOT TAB ===================== */}
          {effectiveActiveTab === 'faq-bot' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
                ))}
              </div>
            }>
              <AdminFaqManager />
            </Suspense>
          )}

          {/* ===================== P2P TAB ===================== */}
          {effectiveActiveTab === 'p2p' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
                ))}
              </div>
            }>
              <AdminP2P />
            </Suspense>
          )}

          {/* ===================== AUDIT LOG TAB ===================== */}
          {effectiveActiveTab === 'audit-log' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-16 rounded-xl" />
                ))}
              </div>
            }>
              <AdminAuditLog />
            </Suspense>
          )}

          {/* ===================== REPORTS TAB ===================== */}
          {effectiveActiveTab === 'reports' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
                ))}
              </div>
            }>
              <AdminReports />
            </Suspense>
          )}

          {/* ===================== SYSTEM MONITOR TAB ===================== */}
          {effectiveActiveTab === 'system-monitor' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
                ))}
              </div>
            }>
              <AdminSystemMonitor />
            </Suspense>
          )}

          {/* ===================== ADMIN TEAM TAB ===================== */}
          {effectiveActiveTab === 'admin-team' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-28 rounded-xl" />
                ))}
              </div>
            }>
              <AdminTeam />
            </Suspense>
          )}

          {/* ===================== ADMIN FINANCIAL TAB ===================== */}
          {effectiveActiveTab === 'admin-financial' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
                ))}
              </div>
            }>
              <AdminFinancial />
            </Suspense>
          )}

          {/* ===================== BANNERS TAB ===================== */}
          {effectiveActiveTab === 'banners' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-32 rounded-xl" />
                ))}
              </div>
            }>
              <BannerManager />
            </Suspense>
          )}

          {/* ===================== PROMO TAB ===================== */}
          {effectiveActiveTab === 'promo' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-32 rounded-xl" />
                ))}
              </div>
            }>
              <PromoManager />
            </Suspense>
          )}

          {/* ===================== SUPER ADMIN TAB ===================== */}
          {effectiveActiveTab === 'super-admin' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
                ))}
              </div>
            }>
              <SuperAdminPanel />
            </Suspense>
          )}

          {effectiveActiveTab === 'withdrawal-reports' && (
            <Suspense fallback={
              <div className="space-y-3">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="glass-card p-4 shimmer h-24 rounded-xl" />
                ))}
              </div>
            }>
              <AdminWithdrawalReports />
            </Suspense>
          )}

          {effectiveActiveTab === 'firebase-config' && (
            <Suspense fallback={<div className="glass-card p-8 text-center"><Loader2 className="w-6 h-6 animate-spin mx-auto text-gold" /></div>}>
              <FirebaseConfig />
            </Suspense>
          )}

          {/* ===================== KYC TAB ===================== */}
          {effectiveActiveTab === 'kyc' && (() => {
            // Group records by user
            const grouped = new Map<string, { user: KYCRecordItem['user']; records: KYCRecordItem[] }>()
            for (const k of kycRecords) {
              const uid = k.userId || 'unknown'
              if (!grouped.has(uid)) grouped.set(uid, { user: k.user, records: [] })
              grouped.get(uid)!.records.push(k)
            }
            const entries = Array.from(grouped.entries())
            const detailUser = kycDetailUser ? entries.find(([uid]) => uid === kycDetailUser) : null

            return (
              <>
                {/* User List */}
                <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                  {entries.length === 0 ? (
                    <div className="glass-card p-8 text-center text-muted-foreground text-sm">لا توجد طلبات تحقق</div>
                  ) : (
                    entries.map(([uid, { user: userInfo, records }]) => {
                      const hasPending = records.some(r => r.status === 'pending')
                      const allApproved = records.every(r => r.status === 'approved')
                      const allRejected = records.every(r => r.status === 'rejected')
                      const idPhoto = records.find(r => r.type === 'id_photo')
                      const idBack = records.find(r => r.type === 'id_back')

                      return (
                        <button
                          key={uid}
                          onClick={() => setKycDetailUser(uid)}
                          className="w-full glass-card rounded-xl p-3 flex items-center gap-3 hover:border-gold/20 transition-all text-right group"
                        >
                          {/* Avatar */}
                          <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                            allApproved ? 'bg-green-500/10 text-green-400' :
                            allRejected ? 'bg-red-500/10 text-red-400' :
                            hasPending ? 'bg-amber-500/10 text-amber-400' :
                            'bg-white/5 text-muted-foreground'
                          }`}>
                            {(userInfo?.fullName || userInfo?.email || '?').charAt(0).toUpperCase()}
                          </div>

                          {/* Info */}
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{userInfo?.fullName || userInfo?.email || 'مستخدم غير معروف'}</p>
                            <div className="flex items-center gap-2 mt-0.5">
                              {userInfo?.phone && <p className="text-[10px] text-muted-foreground">{userInfo.phone}</p>}
                              <span className="text-[10px] text-muted-foreground">{records.length} مستند</span>
                              {idPhoto && <span className="text-[10px] text-muted-foreground">| 🪪 هوية: {idPhoto.status === 'approved' ? '✓' : idPhoto.status === 'rejected' ? '✗' : '⏳'}</span>}
                              {idBack && <span className="text-[10px] text-muted-foreground">| 🪪 ظهر: {idBack.status === 'approved' ? '✓' : idBack.status === 'rejected' ? '✗' : '⏳'}</span>}
                            </div>
                          </div>

                          {/* Status + Arrow */}
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold ${
                              allApproved ? 'bg-green-500/10 text-green-400' :
                              allRejected ? 'bg-red-500/10 text-red-400' :
                              hasPending ? 'bg-amber-500/10 text-amber-400' :
                              'bg-white/5 text-muted-foreground'
                            }`}>
                              {allApproved ? 'مقبول' : allRejected ? 'مرفوض' : hasPending ? 'بانتظار المراجعة' : 'مختلط'}
                            </span>
                            <ChevronDown className="w-4 h-4 text-muted-foreground group-hover:text-gold transition-colors rotate-[-90deg]" />
                          </div>
                        </button>
                      )
                    })
                  )}
                </div>

                {/* ===================== KYC DETAIL MODAL ===================== */}
                {detailUser && (() => {
                  const [uid, { user: userInfo, records }] = detailUser
                  const idPhoto = records.find(r => r.type === 'id_photo')
                  const idBack = records.find(r => r.type === 'id_back')
                  const hasPending = records.some(r => r.status === 'pending')
                  const allApproved = records.every(r => r.status === 'approved')
                  const allRejected = records.every(r => r.status === 'rejected')
                  const anyNotes = records.find(r => r.notes)
                  const pendingRecords = records.filter(r => r.status === 'pending')

                  return (
                    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-3" onClick={() => setKycDetailUser(null)}>
                      <div
                        className="bg-background/95 backdrop-blur-xl w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border border-white/10 max-h-[90vh] overflow-y-auto"
                        style={{ animation: 'scaleIn 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)' }}
                        onClick={(e) => e.stopPropagation()}
                      >
                        {/* Modal Header */}
                        <div className="sticky top-0 bg-background/95 backdrop-blur-xl z-10 p-4 border-b border-white/5 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-base font-bold ${
                              allApproved ? 'bg-green-500/10 text-green-400' :
                              allRejected ? 'bg-red-500/10 text-red-400' :
                              hasPending ? 'bg-amber-500/10 text-amber-400' :
                              'bg-white/5 text-muted-foreground'
                            }`}>
                              {(userInfo?.fullName || userInfo?.email || '?').charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <h3 className="text-base font-bold">{userInfo?.fullName || 'مستخدم غير معروف'}</h3>
                              <p className="text-[10px] text-muted-foreground mt-0.5">{userInfo?.email}</p>
                              {userInfo?.phone && <p className="text-[10px] text-muted-foreground">{userInfo?.phone}</p>}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold ${
                              allApproved ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                              allRejected ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                              hasPending ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                              'bg-white/5 text-muted-foreground border border-white/10'
                            }`}>
                              {allApproved ? '✓ مقبول' : allRejected ? '✗ مرفوض' : hasPending ? '⏳ بانتظار المراجعة' : 'مختلط'}
                            </span>
                            <button onClick={() => setKycDetailUser(null)} className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors">
                              <X className="w-4 h-4 text-muted-foreground" />
                            </button>
                          </div>
                        </div>

                        {/* Modal Body */}
                        <div className="p-4 space-y-4">
                          {/* Photos Grid - Large */}
                          <div className="grid grid-cols-2 gap-3">
                            {/* ID Photo */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5">
                                  <CreditCard className="w-3.5 h-3.5 text-muted-foreground" />
                                  <span className="text-xs font-medium">صورة الهوية</span>
                                </div>
                                {idPhoto && (
                                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                                    idPhoto.status === 'approved' ? 'bg-green-500/10 text-green-400' :
                                    idPhoto.status === 'rejected' ? 'bg-red-500/10 text-red-400' :
                                    'bg-amber-500/10 text-amber-400'
                                  }`}>
                                    {idPhoto.status === 'approved' ? '✓ مقبول' : idPhoto.status === 'rejected' ? '✗ مرفوض' : '⏳ معلق'}
                                  </span>
                                )}
                              </div>
                              {idPhoto ? (
                                <div className="rounded-2xl overflow-hidden border border-white/10 bg-white/5 relative group cursor-pointer aspect-[3/4]" onClick={() => window.open(idPhoto.fileUrl, '_blank')}>
                                  <img
                                    src={idPhoto.fileUrl || ''}
                                    alt="صورة الهوية"
                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                    onError={(e) => {
                                      (e.target as HTMLImageElement).style.display = 'none'
                                      ;(e.target as HTMLImageElement).nextElementSibling?.classList.remove('hidden')
                                    }}
                                  />
                                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <div className="text-center">
                                      <Eye className="w-6 h-6 text-white mx-auto mb-1" />
                                      <p className="text-[10px] text-white">عرض بالحجم الكامل</p>
                                    </div>
                                  </div>
                                  <div className="absolute inset-0 flex items-center justify-center bg-white/5 hidden">
                                    <div className="text-center">
                                      <ImageOff className="w-8 h-8 text-muted-foreground/30 mx-auto mb-1" />
                                      <p className="text-xs text-muted-foreground">فشل التحميل</p>
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <div className="aspect-[3/4] rounded-2xl border-2 border-dashed border-white/10 flex items-center justify-center">
                                  <div className="text-center">
                                    <ImageOff className="w-8 h-8 text-muted-foreground/20 mx-auto mb-1" />
                                    <p className="text-xs text-muted-foreground/50">غير مرفق</p>
                                  </div>
                                </div>
                              )}
                            </div>

                            {/* Selfie */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-1.5">
                                  <FileText className="w-3.5 h-3.5 text-muted-foreground" />
                                  <span className="text-xs font-medium">ظهر الهوية</span>
                                </div>
                                {idBack && (
                                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                                    idBack.status === 'approved' ? 'bg-green-500/10 text-green-400' :
                                    idBack.status === 'rejected' ? 'bg-red-500/10 text-red-400' :
                                    'bg-amber-500/10 text-amber-400'
                                  }`}>
                                    {idBack.status === 'approved' ? '✓ مقبول' : idBack.status === 'rejected' ? '✗ مرفوض' : '⏳ معلق'}
                                  </span>
                                )}
                              </div>
                              {idBack ? (
                                <div className="rounded-2xl overflow-hidden border border-white/10 bg-white/5 relative group cursor-pointer aspect-[3/4]" onClick={() => window.open(idBack.fileUrl, '_blank')}>
                                  <img
                                    src={idBack.fileUrl || ''}
                                    alt="ظهر بطاقة الهوية"
                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                    onError={(e) => {
                                      (e.target as HTMLImageElement).style.display = 'none'
                                      ;(e.target as HTMLImageElement).nextElementSibling?.classList.remove('hidden')
                                    }}
                                  />
                                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <div className="text-center">
                                      <Eye className="w-6 h-6 text-white mx-auto mb-1" />
                                      <p className="text-[10px] text-white">عرض بالحجم الكامل</p>
                                    </div>
                                  </div>
                                  <div className="absolute inset-0 flex items-center justify-center bg-white/5 hidden">
                                    <div className="text-center">
                                      <ImageOff className="w-8 h-8 text-muted-foreground/30 mx-auto mb-1" />
                                      <p className="text-xs text-muted-foreground">فشل التحميل</p>
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <div className="aspect-[3/4] rounded-2xl border-2 border-dashed border-white/10 flex items-center justify-center">
                                  <div className="text-center">
                                    <ImageOff className="w-8 h-8 text-muted-foreground/20 mx-auto mb-1" />
                                    <p className="text-xs text-muted-foreground/50">غير مرفق</p>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Reject Notes */}
                          {anyNotes && (
                            <div className="p-3 rounded-2xl bg-yellow-500/5 border border-yellow-500/10">
                              <p className="text-xs text-yellow-400 font-bold mb-1">⚠️ ملاحظات الرفض:</p>
                              {records.filter(r => r.notes).map(r => (
                                <p key={r.id} className="text-xs text-muted-foreground mt-1">
                                  {r.type === 'id_photo' ? '🪪 الهوية' : '🧑 الصورة الشخصية'}: {r.notes}
                                </p>
                              ))}
                            </div>
                          )}

                          {/* Action Buttons */}
                          {hasPending && pendingRecords.length > 0 && (
                            <div className="space-y-2 pt-1">
                              <div className="flex gap-2">
                                <button
                                  onClick={() => {
                                    pendingRecords.forEach(r => handleUpdateKYC(r.id, 'approved', r.userId!))
                                    if (pendingRecords.every(r => records.length === pendingRecords.length)) setKycDetailUser(null)
                                  }}
                                  className="flex-1 flex items-center justify-center gap-2 text-sm py-3 rounded-xl bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-all border border-green-500/15 font-bold"
                                >
                                  <Check className="w-4 h-4" /> قبول الكل
                                </button>
                                <button
                                  onClick={() => { setKycRejectDialog({ recordId: pendingRecords[0].id, userId: pendingRecords[0].userId! }); setKycRejectReason('') }}
                                  className="flex-1 flex items-center justify-center gap-2 text-sm py-3 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-all border border-red-500/15 font-bold"
                                >
                                  <X className="w-4 h-4" /> رفض
                                </button>
                              </div>
                              {pendingRecords.length > 1 && (
                                <div className="grid grid-cols-2 gap-2">
                                  {pendingRecords.map(r => (
                                    <div key={r.id} className="flex gap-1.5">
                                      <button
                                        onClick={() => {
                                          handleUpdateKYC(r.id, 'approved', r.userId!)
                                          if (records.filter(x => x.status === 'pending').length <= 1) setKycDetailUser(null)
                                        }}
                                        className="flex-1 flex items-center justify-center gap-1 text-[11px] py-2 rounded-xl bg-green-500/5 text-green-400/80 hover:bg-green-500/15 transition-colors border border-green-500/10"
                                      >
                                        <Check className="w-3 h-3" /> {r.type === 'id_photo' ? 'قبول الهوية' : 'قبول الصورة'}
                                      </button>
                                      <button
                                        onClick={() => { setKycRejectDialog({ recordId: r.id, userId: r.userId! }); setKycRejectReason('') }}
                                        className="flex-1 flex items-center justify-center gap-1 text-[11px] py-2 rounded-xl bg-red-500/5 text-red-400/80 hover:bg-red-500/15 transition-colors border border-red-500/10"
                                      >
                                        <X className="w-3 h-3" /> {r.type === 'id_photo' ? 'رفض الهوية' : 'رفض الصورة'}
                                      </button>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )
                })()}
              </>
            )
          })()}
        </div>
      )}

      {/* ===================== DEVICE MANAGEMENT DIALOG ===================== */}
      {deviceDialogUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setDeviceDialogUser(null)}>
          <div className="glass-card bg-background/95 backdrop-blur-xl border-purple-500/20 w-full max-w-sm rounded-2xl p-6 space-y-4 animate-scale-in max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-purple-500/10 flex items-center justify-center mx-auto">
                <Settings className="w-7 h-7 text-purple-400" />
              </div>
              <h3 className="text-lg font-bold">إدارة أجهزة المستخدم</h3>
              <p className="text-sm text-muted-foreground">{deviceDialogUser.fullName || deviceDialogUser.email}</p>
            </div>

            <div className={`p-3 rounded-xl text-xs ${deviceDialogUser.status === 'locked_device' ? 'bg-red-500/5 border border-red-500/10 text-red-400' : 'bg-green-500/5 border border-green-500/10 text-green-400'}`}>
              {deviceDialogUser.status === 'locked_device'
                ? '🔒 الحساب مقفل - يجب تصريح جهاز جديد لفتحه'
                : '✓ الحساب مفتوح'}
            </div>

            {/* Pending Device Info */}
            {pendingDevice ? (
              <div className="p-3 rounded-xl bg-yellow-500/5 border border-yellow-500/10 text-xs text-yellow-400 space-y-1">
                <p className="font-medium">📱 طلب تصريح معلق:</p>
                <p>الجهاز: {pendingDevice.deviceName || 'جهاز غير معروف'}</p>
                <p className="text-[10px]" dir="ltr">البصمة: {pendingDevice.fingerprint ? pendingDevice.fingerprint.substring(0, 24) + '...' : 'N/A'}</p>
                <p className="text-[10px]">الوقت: {pendingDevice.requestedAt ? new Date(pendingDevice.requestedAt).toLocaleDateString('ar-SA') : 'غير معروف'}</p>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-muted-foreground text-center">
                لا يوجد طلب تصريح معلق. اطلب من المستخدم تسجيل الدخول من الجهاز الجديد أولاً.
              </div>
            )}

            {/* Current Devices */}
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground font-medium">الأجهزة المسجلة ({deviceList.length}):</p>
              {deviceList.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center p-3">لا توجد أجهزة مسجلة</p>
              ) : (
                deviceList.map((d: any) => (
                  <div key={d.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                    <div>
                      <p className="text-xs font-medium">{d.deviceName || 'جهاز غير معروف'}</p>
                      <p className="text-[10px] text-muted-foreground font-mono" dir="ltr">
                        {d.fingerprint ? d.fingerprint.substring(0, 16) + '...' : 'N/A'}
                      </p>
                      <p className="text-[10px] text-muted-foreground">
                        آخر استخدام: {d.lastUsed ? new Date(d.lastUsed).toLocaleDateString('ar-SA') : 'غير معروف'}
                      </p>
                    </div>
                    <span className="w-2 h-2 rounded-full bg-green-400" />
                  </div>
                ))
              )}
            </div>

            {/* Authorize/Remove buttons */}
            <div className="space-y-3 border-t border-white/5 pt-4">
              <button
                onClick={handleAuthorizeDevice}
                disabled={deviceLoading || !pendingDevice}
                className="w-full h-10 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all text-sm"
              >
                {deviceLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تصريح الجهاز المعلق'}
              </button>
              {deviceList.length > 0 && (
                <button
                  onClick={handleRemoveAllDevices}
                  disabled={deviceLoading}
                  className="w-full h-10 bg-red-500/10 text-red-400 hover:bg-red-500/20 font-medium rounded-xl transition-all text-sm"
                >
                  إزالة جميع الأجهزة
                </button>
              )}
              <button
                onClick={() => setDeviceDialogUser(null)}
                className="w-full h-10 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all text-sm"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== DELETE USER DIALOG ===================== */}
      {deleteDialogUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={closeDeleteDialog}>
          <div className="glass-card bg-background/95 backdrop-blur-xl border-red-500/20 w-full max-w-sm rounded-2xl p-6 space-y-5 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            {deleteStep === 'confirm' && (
              <>
                <div className="text-center space-y-2">
                  <div className="w-14 h-14 rounded-2xl bg-red-500/10 flex items-center justify-center mx-auto">
                    <Trash2 className="w-7 h-7 text-red-400" />
                  </div>
                  <h3 className="text-lg font-bold text-red-400">حذف المستخدم</h3>
                  <p className="text-sm text-muted-foreground">
                    {deleteDialogUser.fullName || deleteDialogUser.email}
                  </p>
                </div>
                <button onClick={handleSendDeleteOtp} disabled={deleteLoading} className="w-full h-11 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-all text-sm">
                  {deleteLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'التالي'}
                </button>
                <button onClick={closeDeleteDialog} className="w-full h-10 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all text-sm">إلغاء</button>
              </>
            )}
            {deleteStep === 'otp' && (
              <>
                <div className="text-center space-y-2">
                  <p className="text-sm">أدخل رمز التحقق المرسل إلى بريدك</p>
                  <Input
                    value={deleteOtp}
                    onChange={(e) => setDeleteOtp(e.target.value)}
                    className="glass-input h-12 text-base text-center tracking-[0.3em] font-mono"
                    placeholder="000000"
                    maxLength={6}
                    dir="ltr"
                  />
                </div>
                <button onClick={handleVerifyDeleteOtp} disabled={deleteLoading || deleteOtp.length !== 6} className="w-full h-11 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-all text-sm">
                  {deleteLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تحقق'}
                </button>
                <button onClick={closeDeleteDialog} className="w-full h-10 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all text-sm">إلغاء</button>
              </>
            )}
            {deleteStep === 'password' && (
              <>
                <div className="text-center space-y-2">
                  <p className="text-sm">أدخل كلمة المرور للإدارة للتأكيد الحذف</p>
                  <Input
                    value={deletePassword}
                    onChange={(e) => setDeletePassword(e.target.value)}
                    type="password"
                    className="glass-input h-12 text-base"
                    placeholder="أدخل كلمة المرور"
                    dir="ltr"
                  />
                </div>
                <button onClick={handleConfirmDelete} disabled={deleteLoading || !deletePassword} className="w-full h-11 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-all">
                  {deleteLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'حذف نهائي'}
                </button>
                <button onClick={closeDeleteDialog} className="w-full h-10 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all text-sm">إلغاء</button>
              </>
            )}
          </div>
        </div>
      )}

      {/* ===================== ROLE CHANGE DIALOG ===================== */}
      {roleDialogUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setRoleDialogUser(null)}>
          <div className="glass-card bg-background/95 backdrop-blur-xl border-gold/20 w-full max-w-sm rounded-2xl p-6 space-y-5 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-gold/10 flex items-center justify-center mx-auto">
                <Crown className="w-7 h-7 text-gold" />
              </div>
              <h3 className="text-lg font-bold">
                {roleDialogUser.role === 'admin' ? 'إزالة صلاحية الإدارة' : 'ترقية إلى إدارة'}
              </h3>
              <p className="text-sm text-muted-foreground">
                {roleDialogUser.fullName || roleDialogUser.email}
              </p>
            </div>

            {roleDialogUser.role !== 'admin' && (
              <div className="space-y-3">
                <p className="text-xs text-muted-foreground font-medium">اختر الصلاحيات:</p>
                {[
                  { key: 'manageUsers' as const, label: 'إدارة المستخدمين (تعليق/تفعيل)', icon: UserCheck },
                  { key: 'approveDeposits' as const, label: 'الموافقة على الإيداعات', icon: ArrowDownLeft },
                  { key: 'approveWithdrawals' as const, label: 'الموافقة على السحوبات', icon: ArrowUpRight },
                  { key: 'approveKYC' as const, label: 'الموافقة على الهويات (KYC)', icon: BadgeCheck },
                ].map((perm) => (
                  <label
                    key={perm.key}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={selectedPermissions[perm.key]}
                      onChange={(e) => setSelectedPermissions({ ...selectedPermissions, [perm.key]: e.target.checked })}
                      className="w-4 h-4 rounded accent-gold"
                    />
                    <perm.icon className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{perm.label}</span>
                  </label>
                ))}
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={confirmRoleChange}
                disabled={actionLoading === roleDialogUser.id}
                className="flex-1 h-11 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all"
              >
                {actionLoading === roleDialogUser.id ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> :
                 roleDialogUser.role === 'admin' ? 'إزالة الإدارة' : 'ترقية'}
              </button>
              <button
                onClick={() => setRoleDialogUser(null)}
                className="flex-1 h-11 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== CONFIRM DEPOSIT DIALOG (with PIN) ===================== */}
      {depositConfirmDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => { setDepositConfirmDialog(null); setDepositConfirmPin('') }}>
          <div className="glass-card bg-background/95 backdrop-blur-xl border-green-500/20 w-full max-w-sm rounded-2xl p-6 space-y-5 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-green-500/10 flex items-center justify-center mx-auto">
                <Check className="w-7 h-7 text-green-400" />
              </div>
              <h3 className="text-lg font-bold text-green-400">تأكيد الإيداع</h3>
              <p className="text-xs text-muted-foreground">{depositConfirmDialog.userName}</p>
            </div>
            {/* Amount details */}
            <div className="p-3 rounded-xl bg-white/5 text-sm space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">المبلغ المدفوع</span>
                <span className="font-bold">{depositConfirmDialog.amount.toFixed(2)} USDT</span>
              </div>
              {depositConfirmDialog.fee > 0 && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">الرسوم → حساب الإدارة</span>
                  <span className="font-bold text-gold">-{depositConfirmDialog.fee.toFixed(2)} USDT</span>
                </div>
              )}
              <div className="border-t border-white/10 pt-2 flex justify-between">
                <span className="text-muted-foreground">المبلغ الصافي الذي سيُضاف</span>
                <span className="font-bold text-green-400">{depositConfirmDialog.netAmount.toFixed(2)} USDT</span>
              </div>
            </div>
            {/* PIN input */}
            <div className="space-y-3">
              <Label className="text-sm text-muted-foreground">أدخل رمز PIN للتأكيد</Label>
              <input
                type="password"
                value={depositConfirmPin}
                onChange={(e) => setDepositConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="• • • •"
                className="w-full h-12 rounded-xl glass-input px-4 text-sm tracking-widest text-center text-xl"
                dir="ltr"
                maxLength={6}
                autoFocus
              />
              <button onClick={handleConfirmDeposit} disabled={depositConfirmLoading || depositConfirmPin.length < 4} className="w-full h-11 bg-green-500 text-white font-bold rounded-xl hover:bg-green-600 transition-all disabled:opacity-50">
                {depositConfirmLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تأكيد الإيداع'}
              </button>
              <button onClick={() => { setDepositConfirmDialog(null); setDepositConfirmPin('') }} className="w-full h-10 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== REJECT DEPOSIT DIALOG ===================== */}
      {depositRejectDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => { setDepositRejectDialog(null); setDepositRejectReason('') }}>
          <div className="glass-card bg-background/95 backdrop-blur-xl border-red-500/20 w-full max-w-sm rounded-2xl p-6 space-y-5 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-red-500/10 flex items-center justify-center mx-auto">
                <X className="w-7 h-7 text-red-400" />
              </div>
              <h3 className="text-lg font-bold text-red-400">رفض الإيداع</h3>
              <p className="text-sm text-muted-foreground">
                مبلغ: <strong className="text-foreground">{(depositRejectDialog.amount ?? 0).toFixed(2)} USDT</strong>
              </p>
            </div>
            <div className="space-y-3">
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">سبب الرفض</Label>
                <textarea
                  value={depositRejectReason}
                  onChange={(e) => setDepositRejectReason(e.target.value)}
                  className="w-full h-24 rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm text-foreground resize-none"
                  placeholder="أدخل سبب رفض الإيداع..."
                />
              </div>
              <button onClick={handleRejectDeposit} disabled={depositRejectLoading || !depositRejectReason.trim()} className="w-full h-11 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-all">
                {depositRejectLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تأكيد الرفض'}
              </button>
              <button onClick={() => { setDepositRejectDialog(null); setDepositRejectReason('') }} className="w-full h-10 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== REJECT WITHDRAWAL DIALOG ===================== */}
      {rejectDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setRejectDialog(null)}>
          <div className="glass-card bg-background/95 backdrop-blur-xl border-red-500/20 w-full max-w-sm rounded-2xl p-6 space-y-5 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-red-500/10 flex items-center justify-center mx-auto">
                <X className="w-7 h-7 text-red-400" />
              </div>
              <h3 className="text-lg font-bold text-red-400">رفض السحب</h3>
              <p className="text-sm text-muted-foreground">
                مبلغ: <strong className="text-foreground">{(rejectDialog.amount ?? 0).toFixed(2)} USDT</strong>
              </p>
            </div>
            <div className="space-y-3">
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">سبب الرفض</Label>
                <textarea
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  className="w-full h-24 rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm text-foreground resize-none"
                  placeholder="أدخل سبب رفض السحب..."
                />
              </div>
              <button onClick={handleRejectWithReason} disabled={rejectLoading || !rejectReason.trim()} className="w-full h-11 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-all">
                {rejectLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تأكيد الرفض'}
              </button>
              <button onClick={() => setRejectDialog(null)} className="w-full h-10 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== KYC REJECT DIALOG ===================== */}
      {kycRejectDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setKycRejectDialog(null)}>
          <div className="glass-card bg-background/95 backdrop-blur-xl border-red-500/20 w-full max-w-sm rounded-2xl p-6 space-y-5 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-red-500/10 flex items-center justify-center mx-auto">
                <X className="w-7 h-7 text-red-400" />
              </div>
              <h3 className="text-lg font-bold text-red-400">رفض المستند</h3>
            </div>
            <div className="space-y-3">
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">سبب الرفض</Label>
                <textarea
                  value={kycRejectReason}
                  onChange={(e) => setKycRejectReason(e.target.value)}
                  className="w-full h-24 rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm text-foreground resize-none"
                  placeholder="أدخل سبب الرفض..."
                />
              </div>
              <button onClick={() => handleUpdateKYC(kycRejectDialog.recordId, 'rejected', kycRejectDialog.userId, kycRejectReason)} disabled={kycRejectLoading || !kycRejectReason.trim()} className="w-full h-11 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-all">
                {kycRejectLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تأكيد الرفض'}
              </button>
              <button onClick={() => setKycRejectDialog(null)} className="w-full h-10 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== PAYMENT PROOF DIALOG ===================== */}
      {proofDialogWithdrawal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setProofDialogWithdrawal(null)}>
          <div className="glass-card bg-background/95 backdrop-blur-xl border-gold/20 w-full max-w-sm rounded-2xl p-6 space-y-5 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-2xl bg-gold/10 flex items-center justify-center mx-auto">
                <Upload className="w-7 h-7 text-gold" />
              </div>
              <h3 className="text-lg font-bold gold-text">رفع صورة الدفع</h3>
              <p className="text-sm text-muted-foreground">
                مبلغ: <strong className="text-foreground">{(proofDialogWithdrawal.amount ?? 0).toFixed(2)} USDT</strong>
              </p>
            </div>
            <div className="space-y-3">
              <div className="flex flex-col items-start gap-2 rounded-xl bg-white/5 border border-white/10 p-3 cursor-pointer hover:border-gold/30 transition-colors">
                <label className="text-xs text-muted-foreground">صورة إثبات الدفع</label>
                <input
                  ref={proofInputRef}
                  type="file"
                  accept="image/*"
                  className="w-full text-sm text-foreground file:mr-2 file:ml-0 file:rounded-lg file:border-0 file:bg-transparent file:text-foreground file:font-medium"
                />
              </div>
              <button onClick={handleUploadProof} disabled={proofLoading} className="w-full h-11 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all">
                {proofLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'رفع الصورة وتأكيد السحب'}
              </button>
              <button onClick={() => setProofDialogWithdrawal(null)} className="w-full h-10 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== FULL IMAGE PREVIEW ===================== */}
      {previewImage && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60] flex items-center justify-center p-4" onClick={() => setPreviewImage(null)}>
          <div className="relative max-w-lg w-full animate-scale-in">
            <img src={previewImage} alt="معاينة" className="w-full rounded-xl" onClick={(e) => e.stopPropagation()} />
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-3 left-3 w-8 h-8 bg-black/60 rounded-full flex items-center justify-center hover:bg-black/80"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ===================== BALANCE ADJUSTMENT DIALOG ===================== */}
      {balanceDialogUser && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={() => setBalanceDialogUser(null)}>
          <div className="glass-card p-6 space-y-4 w-full max-w-sm animate-scale-in" onClick={e => e.stopPropagation()} dir="rtl">
            <div className="text-center space-y-2">
              <div className={`w-14 h-14 mx-auto rounded-2xl flex items-center justify-center ${balanceAction === 'add' ? 'bg-green-500/10' : 'bg-orange-500/10'}`}>
                {balanceAction === 'add' ? <ArrowDownLeft className="w-7 h-7 text-green-400" /> : <ArrowUpRight className="w-7 h-7 text-orange-400" />}
              </div>
              <h3 className="text-lg font-bold">{balanceAction === 'add' ? 'إضافة رصيد' : 'سحب رصيد'}</h3>
              <p className="text-sm text-muted-foreground">{balanceDialogUser.fullName || balanceDialogUser.email}</p>
              <p className="text-xs text-muted-foreground">الرصيد الحالي: <span className="gold-text font-bold">{(balanceDialogUser.balance ?? 0).toFixed(2)} USDT</span></p>
            </div>
            <div className="space-y-3">
              <input
                type="number"
                value={balanceAmount}
                onChange={(e) => setBalanceAmount(e.target.value)}
                placeholder="المبلغ (USDT)"
                className="w-full h-12 rounded-xl glass-input px-4 text-sm"
                dir="ltr"
                min="0"
                step="0.01"
              />
              {balanceAmount && parseFloat(balanceAmount) > 0 && (
                <p className="text-xs text-center">
                  الرصيد بعد العملية: <span className={`font-bold ${balanceAction === 'add' ? 'text-green-400' : 'text-orange-400'}`}>
                    {((balanceDialogUser.balance ?? 0) + (balanceAction === 'add' ? parseFloat(balanceAmount) : -parseFloat(balanceAmount))).toFixed(2)} USDT
                  </span>
                </p>
              )}
              <button
                onClick={handleAdjustBalance}
                disabled={balanceLoading || !balanceAmount || parseFloat(balanceAmount) <= 0}
                className={`w-full h-12 font-bold rounded-xl hover:opacity-90 transition-all disabled:opacity-50 ${
                  balanceAction === 'add' ? 'bg-green-500 text-white' : 'bg-orange-500 text-white'
                }`}
              >
                {balanceLoading ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : balanceAction === 'add' ? 'تأكيد الإضافة' : 'تأكيد السحب'}
              </button>
              <button
                onClick={() => setBalanceDialogUser(null)}
                className="w-full h-10 bg-white/10 text-foreground rounded-xl text-sm"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== REMOVE MERCHANT CONFIRMATION DIALOG ===================== */}
      {removeMerchantDialogUser && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={() => setRemoveMerchantDialogUser(null)}>
          <div className="glass-card p-6 space-y-4 w-full max-w-sm animate-scale-in" onClick={e => e.stopPropagation()} dir="rtl">
            <div className="text-center space-y-3">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-orange-500/10 flex items-center justify-center">
                <AlertTriangle className="w-7 h-7 text-orange-400" />
              </div>
              <h3 className="text-lg font-bold text-orange-400">إزالة حالة التاجر</h3>
              <p className="text-sm text-muted-foreground">
                سيتم تحويل حساب <strong>{removeMerchantDialogUser.fullName || removeMerchantDialogUser.email}</strong> من تاجر إلى مستخدم عادي.
              </p>
              <div className="p-3 rounded-xl bg-red-500/5 border border-red-500/10">
                <p className="text-xs text-red-400">⚠️ سيتم حذف جميع إعلانات P2P المرتبطة بهذا التاجر ولن يتمكن من إنشاء إعلانات جديدة.</p>
              </div>
            </div>
            <div className="space-y-2">
              <button
                onClick={handleRemoveMerchant}
                disabled={removeMerchantLoading}
                className="w-full h-12 bg-orange-500 text-white font-bold rounded-xl hover:opacity-90 transition-all disabled:opacity-50"
              >
                {removeMerchantLoading ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : 'تأكيد إزالة التاجر'}
              </button>
              <button
                onClick={() => setRemoveMerchantDialogUser(null)}
                className="w-full h-10 bg-white/10 text-foreground rounded-xl text-sm"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== RESET KYC CONFIRMATION DIALOG ===================== */}
      {resetKycDialogUser && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={() => setResetKycDialogUser(null)}>
          <div className="glass-card p-6 space-y-4 w-full max-w-sm animate-scale-in" onClick={e => e.stopPropagation()} dir="rtl">
            <div className="text-center space-y-3">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-cyan-500/10 flex items-center justify-center">
                <Shield className="w-7 h-7 text-cyan-400" />
              </div>
              <h3 className="text-lg font-bold text-cyan-400">تحديث الهوية</h3>
              <p className="text-sm text-muted-foreground">
                سيتم إعادة تعيين حالة التوثيق لحساب <strong>{resetKycDialogUser.fullName || resetKycDialogUser.email}</strong>.
              </p>
              <div className="p-3 rounded-xl bg-cyan-500/5 border border-cyan-500/10">
                <p className="text-xs text-cyan-400">
                  {resetKycDialogUser.merchantId
                    ? 'سيتم حذف جميع مستندات التوثيق الحالية ويجب على التاجر إعادة رفع مستندات الهوية لتوثيق حسابه من جديد.'
                    : 'سيتم حذف جميع مستندات التوثيق الحالية ويجب على المستخدم إعادة رفع مستندات الهوية لتوثيق حسابه من جديد.'
                  }
                </p>
              </div>
              <p className="text-[11px] text-muted-foreground">سيتم إرسال إشعار للمستخدم بضرورة التوثيق من جديد.</p>
            </div>
            <div className="space-y-2">
              <button
                onClick={handleResetKyc}
                disabled={resetKycLoading}
                className="w-full h-12 bg-cyan-500 text-white font-bold rounded-xl hover:opacity-90 transition-all disabled:opacity-50"
              >
                {resetKycLoading ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : 'تأكيد تحديث الهوية'}
              </button>
              <button
                onClick={() => setResetKycDialogUser(null)}
                className="w-full h-10 bg-white/10 text-foreground rounded-xl text-sm"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ===================== PAYMENT METHODS MANAGER =====================

const CRYPTO_NETWORKS = [
  { value: 'TRC20', label: 'TRC20 (Tron)' },
  { value: 'BEP20', label: 'BEP20 (BSC)' },
  { value: 'ERC20', label: 'ERC20 (Ethereum)' },
  { value: 'SOL', label: 'SOL (Solana)' },
  { value: 'POLYGON', label: 'Polygon' },
  { value: 'ARBITRUM', label: 'Arbitrum' },
  { value: 'OPTIMISM', label: 'Optimism' },
  { value: 'BTC', label: 'BTC (Bitcoin)' },
]

function PaymentMethodsManager({ methods, onRefresh }: { methods: any[]; onRefresh: () => void }) {
  const [showAdd, setShowAdd] = useState(false)
  const [editMethod, setEditMethod] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    type: 'bank_deposit', category: 'bank',
    network: '', walletAddress: '', accountName: '', accountNumber: '',
    beneficiaryName: '', phone: '', recipientName: '', recipientPhone: '',
    instructions: '', minAmount: '', maxAmount: '',
    purpose: 'deposit', currency: 'USDT',
  })

  const resetForm = () => {
    setForm({ type: 'bank_deposit', category: 'bank', network: '', walletAddress: '', accountName: '', accountNumber: '', beneficiaryName: '', phone: '', recipientName: '', recipientPhone: '', instructions: '', minAmount: '', maxAmount: '', purpose: 'deposit', currency: 'USDT' })
    setEditMethod(null)
    setShowAdd(false)
  }

  const handleEdit = (m: any) => {
    setEditMethod(m)
    setForm({ type: m.type || 'bank_deposit', category: m.category || 'bank', network: m.network || '', walletAddress: m.walletAddress || '', accountName: m.accountName || '', accountNumber: m.accountNumber || '', beneficiaryName: m.beneficiaryName || '', phone: m.phone || '', recipientName: m.recipientName || '', recipientPhone: m.recipientPhone || '', instructions: m.instructions || '', minAmount: m.minAmount?.toString() || '', maxAmount: m.maxAmount?.toString() || '', purpose: m.purpose || 'deposit', currency: m.currency || 'USDT' })
    setShowAdd(true)
  }

  const handleSave = async () => {
    setLoading(true)
    try {
      const body: any = { ...form, isActive: true }
      if (editMethod) {
        body.action = 'update'; body.id = editMethod.id; body.isActive = editMethod.isActive
      } else {
        body.action = 'create'
      }
      const res = await apiFetch('/api/admin/payment-methods', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      })
      const data = await res.json()
      if (data.success) { toast.success(data.message); resetForm(); onRefresh() }
      else { toast.error(data.message) }
    } catch { toast.error('خطأ') }
    finally { setLoading(false) }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذه الطريقة؟')) return
    setLoading(true)
    try {
      const res = await apiFetch('/api/admin/payment-methods', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'delete', id }),
      })
      const data = await res.json()
      if (data.success) { toast.success(data.message); onRefresh() }
      else toast.error(data.message)
    } catch { toast.error('خطأ') }
    finally { setLoading(false) }
  }

  const handleToggle = async (m: any) => {
    try {
      const res = await apiFetch('/api/admin/payment-methods', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update', id: m.id, isActive: !m.isActive }),
      })
      const data = await res.json()
      if (data.success) onRefresh()
      else toast.error(data.message)
    } catch { toast.error('خطأ') }
  }

  const TYPE_LABELS: Record<string, string> = { bank_deposit: 'إيداع بنكي', bank_transfer: 'تحويل بنكي', atm_transfer: 'تحويل عبر صراف', crypto: 'عملات رقمية' }
  const CATEGORY_LABELS: Record<string, string> = { bank: '🏦 بنكي', crypto: '₿ عملات رقمية' }
  const CURRENCY_LABELS: Record<string, string> = { USDT: '💵 دولار', YER: '🇾🇪 ريال يمني', SAR: '🇸🇦 ريال سعودي' }
  const CURRENCY_OPTIONS = [
    { value: 'USDT', label: '💵 دولار (USDT)' },
    { value: 'YER', label: '🇾🇪 ريال يمني (ر.ي)' },
    { value: 'SAR', label: '🇸🇦 ريال سعودي (ر.س)' },
  ]

  const getMethodTitle = (m: any) => {
    if (m.category === 'crypto') { return m.network ? `عملات رقمية - ${m.network}` : 'عملات رقمية' }
    return TYPE_LABELS[m.type] || m.type
  }

  return (
    <div className="space-y-4">
      <button onClick={() => { resetForm(); setShowAdd(true) }} className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gold/10 border border-gold/20 text-gold hover:bg-gold/20 transition-all text-sm font-medium">
        <Plus className="w-4 h-4" /> إضافة طريقة دفع جديدة
      </button>

      {methods.length === 0 ? (
        <div className="glass-card p-8 text-center text-muted-foreground text-sm">لا توجد طرق دفع. أضف طريقة جديدة.</div>
      ) : (
        <div className="space-y-2 max-h-[500px] overflow-y-auto">
          {methods.map((m) => (
            <div key={m.id} className={`glass-card p-4 rounded-xl space-y-2 ${!m.isActive ? 'opacity-50' : ''}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${m.category === 'crypto' ? 'bg-orange-500/10 text-orange-400' : 'bg-blue-500/10 text-blue-400'}`}>
                    {m.category === 'crypto' ? <Wallet className="w-5 h-5" /> : <Building className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{getMethodTitle(m)}</p>
                      {m.currency && m.currency !== 'USDT' && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-gold/10 text-gold font-medium">
                          {CURRENCY_LABELS[m.currency] || m.currency}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-muted-foreground">{CATEGORY_LABELS[m.category] || m.category}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => handleToggle(m)} className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${m.isActive ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                    <Power className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleEdit(m)} className="w-8 h-8 rounded-lg bg-gold/10 text-gold flex items-center justify-center hover:bg-gold/20">
                    <Ban className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleDelete(m.id)} className="w-8 h-8 rounded-lg bg-red-500/10 text-red-400 flex items-center justify-center hover:bg-red-500/20">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="text-xs text-muted-foreground space-y-1 border-t border-white/5 pt-2">
                {m.accountName && <p>اسم المحفظة: <span className="text-foreground">{m.accountName}</span></p>}
                {m.accountNumber && <p>رقم الحساب: <span className="text-foreground" dir="ltr">{m.accountNumber}</span></p>}
                {m.beneficiaryName && <p>اسم المستفيد: <span className="text-foreground">{m.beneficiaryName}</span></p>}
                {m.recipientName && <p>اسم المستلم: <span className="text-foreground">{m.recipientName}</span></p>}
                {m.recipientPhone && <p>رقم الجوال: <span className="text-foreground" dir="ltr">{m.recipientPhone}</span></p>}
                {m.network && <p>الشبكة: <span className="text-foreground">{m.network}</span></p>}
                {m.walletAddress && <p>العنوان: <span className="text-foreground" dir="ltr">{m.walletAddress.substring(0, 20)}...</span></p>}
                {m.instructions && <p>ملاحظات: <span className="text-foreground">{m.instructions}</span></p>}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Dialog */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4" onClick={resetForm}>
          <div className="glass-card bg-background/95 backdrop-blur-xl border-gold/20 w-full sm:max-w-md sm:rounded-2xl rounded-t-2xl flex flex-col max-h-[80vh] mb-16 sm:mb-0 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="p-5 pb-3 border-b border-white/5 flex-shrink-0">
              <h3 className="text-lg font-bold gold-text">{editMethod ? 'تعديل طريقة الدفع' : 'إضافة طريقة دفع جديدة'}</h3>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto flex-1 min-h-0">
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs text-muted-foreground">التصنيف</label>
                    <select value={form.category} onChange={(e) => { const cat = e.target.value; setForm({ ...form, category: cat, type: cat === 'crypto' ? 'crypto' : 'bank_deposit', network: cat === 'crypto' ? form.network : '' }) }} className="w-full h-10 rounded-lg bg-white/5 border border-white/10 px-3 text-sm text-foreground">
                      <option value="bank">🏦 بنكي</option>
                      <option value="crypto">₿ عملات رقمية</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-muted-foreground">النوع</label>
                    <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full h-10 rounded-lg bg-white/5 border border-white/10 px-3 text-sm text-foreground">
                      {form.category === 'bank' ? (
                        <><option value="bank_deposit">إيداع بنكي</option><option value="bank_transfer">تحويل بنكي</option><option value="atm_transfer">تحويل عبر صراف</option></>
                      ) : (
                        <option value="crypto">عملات رقمية</option>
                      )}
                    </select>
                  </div>
                </div>

                {/* Currency Selector - for bank methods */}
                {form.category === 'bank' && (
                  <div className="space-y-1">
                    <label className="text-xs text-muted-foreground">عملة الإيداع</label>
                    <select value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })} className="w-full h-10 rounded-lg bg-white/5 border border-white/10 px-3 text-sm text-foreground">
                      {CURRENCY_OPTIONS.map(c => (
                        <option key={c.value} value={c.value}>{c.label}</option>
                      ))}
                    </select>
                    <p className="text-[10px] text-muted-foreground">
                      {form.currency === 'USDT' ? 'المستخدم يدخل المبلغ بالدولار مباشرة' :
                       form.currency === 'YER' ? 'المستخدم يدخل المبلغ بالريال اليمني ويُحوّل تلقائياً' :
                       'المستخدم يدخل المبلغ بالريال السعودي ويُحوّل تلقائياً'}
                    </p>
                  </div>
                )}

                {form.category === 'bank' && form.type === 'bank_deposit' && (
                  <div className="space-y-2 p-3 rounded-lg bg-blue-500/5 border border-blue-500/10">
                    <p className="text-xs text-blue-400 font-medium">بيانات الإيداع البنكي:</p>
                    <div className="space-y-1">
                      <Input value={form.accountName} onChange={(e) => setForm({ ...form, accountName: e.target.value })} className="glass-input h-9 text-sm" placeholder="اسم المحفظة" />
                      <Input value={form.accountNumber} onChange={(e) => setForm({ ...form, accountNumber: e.target.value })} className="glass-input h-9 text-sm" placeholder="رقم الحساب" dir="ltr" />
                      <Input value={form.beneficiaryName} onChange={(e) => setForm({ ...form, beneficiaryName: e.target.value })} className="glass-input h-9 text-sm" placeholder="اسم المستفيد" />
                    </div>
                  </div>
                )}

                {form.category === 'bank' && form.type === 'bank_transfer' && (
                  <div className="space-y-2 p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/10">
                    <p className="text-xs text-emerald-400 font-medium">بيانات التحويل البنكي:</p>
                    <div className="space-y-1">
                      <Input value={form.recipientName} onChange={(e) => setForm({ ...form, recipientName: e.target.value })} className="glass-input h-9 text-sm" placeholder="اسم المستلم" />
                      <Input value={form.recipientPhone} onChange={(e) => setForm({ ...form, recipientPhone: e.target.value })} className="glass-input h-9 text-sm" placeholder="رقم الجوال" dir="ltr" />
                      <Input value={form.network} onChange={(e) => setForm({ ...form, network: e.target.value })} className="glass-input h-9 text-sm" placeholder="اسم البنك / الشبكة" />
                    </div>
                  </div>
                )}
                {form.category === 'bank' && form.type === 'atm_transfer' && (
                  <div className="space-y-2 p-3 rounded-lg bg-green-500/5 border border-green-500/10">
                    <p className="text-xs text-green-400 font-medium">بيانات التحويل عبر صراف:</p>
                    <div className="space-y-1">
                      <Input value={form.recipientName} onChange={(e) => setForm({ ...form, recipientName: e.target.value })} className="glass-input h-9 text-sm" placeholder="اسم المستلم" />
                      <Input value={form.recipientPhone} onChange={(e) => setForm({ ...form, recipientPhone: e.target.value })} className="glass-input h-9 text-sm" placeholder="رقم الجوال" dir="ltr" />
                      <Input value={form.network} onChange={(e) => setForm({ ...form, network: e.target.value })} className="glass-input h-9 text-sm" placeholder="اسم البنك / الشبكة" />
                    </div>
                  </div>
                )}

                {form.category === 'crypto' && (
                  <div className="space-y-2 p-3 rounded-lg bg-orange-500/5 border border-orange-500/10">
                    <p className="text-xs text-orange-400 font-medium">بيانات المحفظة الرقمية:</p>
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <label className="text-[10px] text-muted-foreground">الشبكة (اختياري)</label>
                        <select value={form.network} onChange={(e) => setForm({ ...form, network: e.target.value })} className="w-full h-9 rounded-lg bg-white/5 border border-white/10 px-3 text-sm text-foreground">
                          <option value="">-- اختر الشبكة --</option>
                          {CRYPTO_NETWORKS.map(n => (
                            <option key={n.value} value={n.value}>{n.label}</option>
                          ))}
                        </select>
                      </div>
                      <Input value={form.walletAddress} onChange={(e) => setForm({ ...form, walletAddress: e.target.value })} className="glass-input h-9 text-sm" placeholder="عنوان المحفظة" dir="ltr" />
                    </div>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">تعليمات إضافية (اختياري)</label>
                  <textarea value={form.instructions} onChange={(e) => setForm({ ...form, instructions: e.target.value })} className="w-full h-20 rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm text-foreground resize-none" placeholder="ملاحظات أو تعليمات للمستخدم..." />
                </div>
              </div>
            </div>

            <div className="p-5 pt-3 border-t border-white/5 flex gap-3 flex-shrink-0">
              <button onClick={handleSave} disabled={loading} className="flex-1 h-11 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all">
                {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : editMethod ? 'حفظ التعديلات' : 'إضافة'}
              </button>
              <button onClick={resetForm} className="flex-1 h-11 bg-white/10 hover:bg-white/20 text-foreground font-medium rounded-xl transition-all">إلغاء</button>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}

// ===================== ADMIN SETTINGS PANEL =====================

function AdminSettingsPanel({ settings, onRefresh }: { settings: { email: string; phone: string | null; hasPIN: boolean }; onRefresh: () => void }) {
  const { user } = useAuthStore()
  const [activeSection, setActiveSection] = useState<'phone' | 'email' | 'password' | 'pin' | 'fees' | 'social' | 'cleanup' | 'bot' | 'devices'>('phone')
  const [loading, setLoading] = useState(false)

  // Phone form
  const [newPhone, setNewPhone] = useState('')
  const [phonePassword, setPhonePassword] = useState('')
  // Email form
  const [newEmail, setNewEmail] = useState('')
  const [emailPassword, setEmailPassword] = useState('')
  // Password form
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  // PIN form
  const [pinPassword, setPinPassword] = useState('')
  const [pinCode, setPinCode] = useState('')
  const [pinConfirm, setPinConfirm] = useState('')
  // Cleanup form
  const [cleanupPassword, setCleanupPassword] = useState('')
  const [cleanupConfirmText, setCleanupConfirmText] = useState('')
  const [cleanupResults, setCleanupResults] = useState<Record<string, number> | null>(null)
  // Fee form
  const [depositFee, setDepositFee] = useState('')
  const [withdrawalFee, setWithdrawalFee] = useState('')
  // Commission settings
  const [p2pFeePercent, setP2pFeePercent] = useState('')
  const [adminCommissionPercent, setAdminCommissionPercent] = useState('')
  // Exchange rates
  const [usdToYer, setUsdToYer] = useState('')
  const [usdToSar, setUsdToSar] = useState('')
  const [sarToYer, setSarToYer] = useState('')
  // Social links form
  const [socialWhatsapp, setSocialWhatsapp] = useState('')
  const [socialPhone, setSocialPhone] = useState('')
  const [socialTelegram, setSocialTelegram] = useState('')
  const [socialFacebook, setSocialFacebook] = useState('')
  const [socialInstagram, setSocialInstagram] = useState('')
  const [socialTwitter, setSocialTwitter] = useState('')
  const [socialTiktok, setSocialTiktok] = useState('')
  // Bot toggle
  const [botEnabledSetting, setBotEnabledSetting] = useState(true)

  // Fetch fees & social links & bot setting on mount
  useEffect(() => {
    fetchFees()
    fetchSocialLinks()
    fetchBotSetting()
  }, [])

  const fetchFees = async () => {
    try {
      const res = await apiFetch('/api/settings?t=' + Date.now(), { cache: 'no-store' })
      const data = await res.json()
      if (data.success && data.settings) {
        setDepositFee(String(data.settings.depositFee || 0))
        setWithdrawalFee(String(data.settings.withdrawalFee || 0.1))
        // Commission
        if (data.settings.commission) {
          setP2pFeePercent(String(data.settings.commission.p2pFeePercent ?? 0.5))
          setAdminCommissionPercent(String(data.settings.commission.adminCommissionPercent ?? 1))
        }
        // Exchange rates
        if (data.settings.exchangeRates) {
          setUsdToYer(String(data.settings.exchangeRates.usdToYer ?? 535))
          setUsdToSar(String(data.settings.exchangeRates.usdToSar ?? 3.75))
          setSarToYer(String(data.settings.exchangeRates.sarToYer ?? 142.67))
        }
      }
    } catch { /* silent */ }
  }

  const fetchSocialLinks = async () => {
    try {
      const res = await apiFetch('/api/admin/social-links')
      const data = await res.json()
      if (data.success && data.socialLinks) {
        setSocialWhatsapp(data.socialLinks.whatsapp || '')
        setSocialPhone(data.socialLinks.phone || '')
        setSocialTelegram(data.socialLinks.telegram || '')
        setSocialFacebook(data.socialLinks.facebook || '')
        setSocialInstagram(data.socialLinks.instagram || '')
        setSocialTwitter(data.socialLinks.twitter || '')
        setSocialTiktok(data.socialLinks.tiktok || '')
      }
    } catch { /* silent */ }
  }

  const fetchBotSetting = () => {
    try {
      const saved = localStorage.getItem('forexyemeni-bot-enabled')
      setBotEnabledSetting(saved === null ? true : saved === 'true')
    } catch {}
 }

  const toggleBotSetting = () => {
    const newState = !botEnabledSetting
    setBotEnabledSetting(newState)
    try {
      localStorage.setItem('forexyemeni-bot-enabled', String(newState))
    } catch {}
    toast.success(newState ? 'تم تفعيل الروبوت' : 'تم إيقاف الروبوت')
  }

  const handleSaveSocialLinks = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/admin/social-links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user?.id,
          role: 'admin',
          whatsapp: socialWhatsapp,
          phone: socialPhone,
          telegram: socialTelegram,
          facebook: socialFacebook,
          instagram: socialInstagram,
          twitter: socialTwitter,
          tiktok: socialTiktok,
        }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم تحديث روابط التواصل الاجتماعي')
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في الاتصال')
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async (actionKey: string, payload?: any) => {
    setLoading(true)
    try {
      const body = payload || {}
      const res = await apiFetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user?.id, action: actionKey, ...body }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.message)
        if (actionKey === 'change_email' && data.message.includes('تسجيل الدخول')) {
          toast.info('سيتم تسجيل الخروج لتحديث البريد')
          setTimeout(() => useAuthStore.getState().logout(), 2000)
        }
        if (actionKey === 'update_fees') fetchFees()
        if (actionKey === 'update_commission') fetchFees()
        if (actionKey === 'update_exchange_rates') {
          // Use server-confirmed values to prevent UI/state mismatch
          if (data.saved) {
            setUsdToYer(String(data.saved.usdToYer))
            setUsdToSar(String(data.saved.usdToSar))
            setSarToYer(String(data.saved.sarToYer))
          }
          await refreshExchangeRates()
        }
        onRefresh()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في الاتصال')
    } finally {
      setLoading(false)
    }
  }

  const handleCleanup = async () => {
    setLoading(true)
    try {
      const res = await apiFetch('/api/admin/cleanup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user?.id, password: cleanupPassword, confirmText: cleanupConfirmText }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.message)
        setCleanupResults(data.results)
        setCleanupPassword('')
        setCleanupConfirmText('')
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('خطأ في الاتصال')
    } finally {
      setLoading(false)
    }
  }

  const sections = [
    { key: 'fees' as const, label: 'الرسوم', icon: DollarSign },
    { key: 'phone' as const, label: 'الهاتف', icon: Phone, hasValue: !!settings.phone, value: settings.phone },
    { key: 'email' as const, label: 'البريد', icon: Mail, hasValue: !!settings.email, value: settings.email },
    { key: 'password' as const, label: 'كلمة المرور', icon: Lock, hasValue: true },
    { key: 'pin' as const, label: 'رمز PIN', icon: Shield, hasValue: settings.hasPIN, value: settings.hasPIN ? 'مُفعّل ✓' : 'غير معين' },
    { key: 'social' as const, label: 'تواصل', icon: MessageCircle },
    { key: 'bot' as const, label: 'الروبوت', icon: MessageSquare },
    { key: 'cleanup' as const, label: 'تنظيف', icon: Trash2 },
    { key: 'devices' as const, label: 'الأجهزة', icon: Smartphone },
  ]

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Info */}
      <div className="glass-card p-4 space-y-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gold/10 flex items-center justify-center">
            <Settings className="w-5 h-5 text-gold" />
          </div>
          <div>
            <h3 className="text-sm font-bold">إعدادات الإدارة</h3>
            <p className="text-[10px] text-muted-foreground">إدارة بيانات الحساب والأمان والرسوم</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs border-t border-white/5 pt-2">
          <div className="flex items-center gap-2 p-2 rounded-lg bg-white/5">
            <Mail className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="truncate" dir="ltr">{settings.email}</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-lg bg-white/5">
            <Phone className="w-3.5 h-3.5 text-muted-foreground" />
            <span dir="ltr">{settings.phone || 'غير محدد'}</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-lg bg-white/5">
            <Lock className="w-3.5 h-3.5 text-muted-foreground" />
            <span>كلمة المرور</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-lg bg-white/5">
            <Shield className={`w-3.5 h-3.5 ${settings.hasPIN ? 'text-green-400' : 'text-red-400'}`} />
            <span>PIN: {settings.hasPIN ? 'مُفعّل ✓' : 'غير مُفعّل ✗'}</span>
          </div>
        </div>
      </div>

      {/* Section Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {sections.map((sec) => (
          <button
            key={sec.key}
            onClick={() => setActiveSection(sec.key)}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs transition-all whitespace-nowrap flex-shrink-0 ${
              activeSection === sec.key
                ? 'bg-gold/10 text-gold border border-gold/20'
                : 'text-muted-foreground hover:text-foreground hover:bg-white/5 border border-transparent'
            }`}
          >
            <sec.icon className="w-4 h-4" />
            {sec.label}
          </button>
        ))}
      </div>

      {/* Fees Section */}
      {activeSection === 'fees' && (
        <div className="glass-card p-5 space-y-4">
          <h3 className="text-sm font-bold">إعدادات الرسوم</h3>
          <p className="text-xs text-muted-foreground">تحديد نسبة الرسوم على الإيداعات والسحوب</p>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">رسوم الإيداع (%)</Label>
              <Input type="number" value={depositFee} onChange={(e) => setDepositFee(e.target.value)} className="glass-input h-10 text-sm" placeholder="0" dir="ltr" step="0.1" min="0" max="100" />
              <p className="text-[10px] text-muted-foreground">النسبة رسوم الإيداع (0 يعني بدون رسوم)</p>
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">رسوم السحب (%)</Label>
              <Input type="number" value={withdrawalFee} onChange={(e) => setWithdrawalFee(e.target.value)} className="glass-input h-10 text-sm" placeholder="0.1" dir="ltr" step="0.1" min="0" max="100" />
              <p className="text-[10px] text-muted-foreground">نسبة رسوم السحب (0.1 يعني 0.1%)</p>
            </div>
          </div>
          <button
            onClick={() => handleSave('update_fees', { depositFee: parseFloat(depositFee) || 0, withdrawalFee: parseFloat(withdrawalFee) || 0.1 })}
            disabled={loading}
            className="w-full h-11 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'حفظ الرسوم'}
          </button>

          {/* === Commission Section === */}
          <div className="border-t border-white/10 pt-4 mt-2 space-y-3">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <Percent className="w-4 h-4 text-amber-400" />
              عمولة التجار P2P
            </h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              عند إتمام أي صفقة P2P، يتم خصم نسبة من التاجر تُضاف تلقائياً لحساب الإدارة. النسبتين يظهرن للتاجر بوضوح عند إنشاء الطلب.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">رسوم P2P للتاجر (%)</Label>
                <Input type="number" value={p2pFeePercent} onChange={(e) => setP2pFeePercent(e.target.value)} className="glass-input h-10 text-sm" placeholder="0.5" dir="ltr" step="0.1" min="0" max="10" />
                <p className="text-[10px] text-muted-foreground">تُخصم من التاجر عند إنشاء الطلب</p>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">عمولة الإدارة (%)</Label>
                <Input type="number" value={adminCommissionPercent} onChange={(e) => setAdminCommissionPercent(e.target.value)} className="glass-input h-10 text-sm" placeholder="1" dir="ltr" step="0.1" min="0" max="50" />
                <p className="text-[10px] text-muted-foreground">تُضاف لحساب الإدارة عند إتمام الصفقة</p>
              </div>
            </div>
            <button
              onClick={() => handleSave('update_commission', { p2pFeePercent: parseFloat(p2pFeePercent) || 0.5, adminCommissionPercent: parseFloat(adminCommissionPercent) || 1 })}
              disabled={loading}
              className="w-full h-11 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 font-bold rounded-xl transition-all"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'حفظ إعدادات العمولة'}
            </button>
          </div>

          {/* === Exchange Rates Section === */}
          <div className="border-t border-white/10 pt-4 mt-2 space-y-3">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-green-400" />
              أسعار الصرف
            </h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              تحديث أسعار الصرف الظاهرة للمستخدمين في المحفظة و P2P والإيداعات
            </p>
            <div className="space-y-3">
              {/* USD to YER */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-l from-green-500/5 to-transparent border border-green-500/10">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-green-500/10 flex-shrink-0">
                  <span className="text-lg">🇺🇸</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-medium text-green-400">دولار أمريكي ← ريال يمني</span>
                    <span className="text-[10px] text-muted-foreground bg-white/5 px-1.5 py-0.5 rounded">1 USD = ? YER</span>
                  </div>
                  <Input
                    type="number"
                    value={usdToYer}
                    onChange={(e) => setUsdToYer(e.target.value)}
                    className="glass-input h-9 text-sm font-bold text-green-400"
                    placeholder="535"
                    dir="ltr"
                    step="1"
                    min="0"
                  />
                </div>
              </div>

              {/* USD to SAR */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-l from-amber-500/5 to-transparent border border-amber-500/10">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-amber-500/10 flex-shrink-0">
                  <span className="text-lg">🇸🇦</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-medium text-amber-400">دولار أمريكي ← ريال سعودي</span>
                    <span className="text-[10px] text-muted-foreground bg-white/5 px-1.5 py-0.5 rounded">1 USD = ? SAR</span>
                  </div>
                  <Input
                    type="number"
                    value={usdToSar}
                    onChange={(e) => setUsdToSar(e.target.value)}
                    className="glass-input h-9 text-sm font-bold text-amber-400"
                    placeholder="3.75"
                    dir="ltr"
                    step="0.01"
                    min="0"
                  />
                </div>
              </div>

              {/* SAR to YER */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-l from-blue-500/5 to-transparent border border-blue-500/10">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-blue-500/10 flex-shrink-0">
                  <div className="text-lg">🔄</div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-medium text-blue-400">ريال سعودي ← ريال يمني</span>
                    <span className="text-[10px] text-muted-foreground bg-white/5 px-1.5 py-0.5 rounded">1 SAR = ? YER</span>
                  </div>
                  <Input
                    type="number"
                    value={sarToYer}
                    onChange={(e) => setSarToYer(e.target.value)}
                    className="glass-input h-9 text-sm font-bold text-blue-400"
                    placeholder="142.67"
                    dir="ltr"
                    step="0.01"
                    min="0"
                  />
                </div>
              </div>
            </div>

            {/* Live preview */}
            <div className="p-3 rounded-xl bg-white/3 border border-white/5">
              <p className="text-[10px] text-muted-foreground mb-2 font-medium">معاينة مباشرة:</p>
              <div className="flex items-center justify-around text-[11px]">
                <div className="text-center">
                  <span className="text-muted-foreground">1$ = </span>
                  <span className="font-bold text-green-400">{Number(usdToYer || 535).toLocaleString()}</span>
                  <span className="text-muted-foreground"> ر.ي</span>
                </div>
                <div className="w-px h-4 bg-white/10" />
                <div className="text-center">
                  <span className="text-muted-foreground">1$ = </span>
                  <span className="font-bold text-amber-400">{Number(usdToSar || 3.75).toFixed(2)}</span>
                  <span className="text-muted-foreground"> ر.س</span>
                </div>
                <div className="w-px h-4 bg-white/10" />
                <div className="text-center">
                  <span className="text-muted-foreground">1 ر.س = </span>
                  <span className="font-bold text-blue-400">{Number(sarToYer || 142.67).toLocaleString()}</span>
                  <span className="text-muted-foreground"> ر.ي</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleSave('update_exchange_rates', {
                usdToYer: parseFloat(usdToYer) || 535,
                usdToSar: parseFloat(usdToSar) || 3.75,
                sarToYer: parseFloat(sarToYer) || 142.67
              })}
              disabled={loading}
              className="w-full h-11 bg-green-500/20 hover:bg-green-500/30 text-green-400 font-bold rounded-xl transition-all flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <>
                <RefreshCw className="w-4 h-4" />
                حفظ أسعار الصرف
              </>}
            </button>
          </div>
        </div>
      )}

      {/* Phone Section */}
      {activeSection === 'phone' && (
        <div className="glass-card p-5 space-y-4">
          <h3 className="text-sm font-bold">تغيير رقم الهاتف</h3>
          <p className="text-xs text-muted-foreground">رقم الهاتف يُستخدم لاستعادة كلمة المرور في حالة فقدان البريد الإلكتروني</p>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">الرقم الحالي</label>
              <Input disabled value={settings.phone ? `+967 ${settings.phone}` : 'غير محدد'} className="glass-input h-10 text-sm opacity-60" dir="ltr" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">الرقم الجديد</label>
              <Input value={newPhone} onChange={(e) => setNewPhone(e.target.value)} className="glass-input h-10 text-sm" placeholder="7XXXXXXXX" dir="ltr" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">كلمة المرور للتأكيد</label>
              <Input type="password" value={phonePassword} onChange={(e) => setPhonePassword(e.target.value)} className="glass-input h-10 text-sm" placeholder="أدخل كلمة المرور" dir="ltr" />
            </div>
          </div>
          <button onClick={() => handleSave('change_phone', { action: 'change_phone', newPhone, currentPassword: phonePassword })} disabled={loading || !newPhone || !phonePassword} className="w-full h-11 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all">
            {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تغيير الرقم'}
          </button>
        </div>
      )}

      {/* Email Section */}
      {activeSection === 'email' && (
        <div className="glass-card p-5 space-y-4">
          <h3 className="text-sm font-bold">تغيير البريد الإلكتروني</h3>
          <div className="p-3 rounded-lg bg-gold/5 border border-gold/10 text-xs text-gold">
            ⚠️ تغيير البريد يتطلب تسجيل الدخول بالبريد الجديد
          </div>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">البريد الحالي</label>
              <Input disabled value={settings.email} className="glass-input h-10 text-sm opacity-60" dir="ltr" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">البريد الجديد</label>
              <Input type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} className="glass-input h-10 text-sm" placeholder="new@email.com" dir="ltr" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">كلمة المرور للتأكيد</label>
              <Input type="password" value={emailPassword} onChange={(e) => setEmailPassword(e.target.value)} className="glass-input h-10 text-sm" placeholder="أدخل كلمة المرور" dir="ltr" />
            </div>
          </div>
          <button onClick={() => handleSave('change_email', { action: 'change_email', newEmail, currentPassword: emailPassword })} disabled={loading || !newEmail || !emailPassword} className="w-full h-11 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all">
            {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تغيير البريد'}
          </button>
        </div>
      )}

      {/* Password Section */}
      {activeSection === 'password' && (
        <div className="glass-card p-5 space-y-4">
          <h3 className="text-sm font-bold">تغيير كلمة المرور</h3>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">كلمة المرور الحالية</label>
              <Input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} className="glass-input h-10 text-sm" placeholder="أدخل كلمة المرور الحالية" dir="ltr" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">كلمة المرور الجديدة (8 أحرف على الأقل)</label>
              <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="glass-input h-10 text-sm" placeholder="أدخل كلمة المرور الجديدة" dir="ltr" />
            </div>
          </div>
          <button onClick={() => handleSave('change_password', { action: 'change_password', currentPassword, newPassword })} disabled={loading || !currentPassword || !newPassword || newPassword.length < 8} className="w-full h-11 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all">
            {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'تغيير كلمة المرور'}
          </button>
        </div>
      )}

      {/* PIN Section */}
      {activeSection === 'pin' && (
        <div className="glass-card p-5 space-y-4">
          <h3 className="text-sm font-bold">رمز PIN للاستعادة</h3>
          <p className="text-xs text-muted-foreground">رمز PIN يُستخدم لاستعادة كلمة المرور عند فقدان البريد الإلكتروني. يجب أن يكون بين 4 و 8 أرقام.</p>

          {settings.hasPIN ? (
            <div className="p-3 rounded-lg bg-green-500/5 border border-green-500/10 text-xs text-green-400">
              ✓ تم تعيين رمز PIN بالفعل. يمكنك تغييره أدناه.
            </div>
          ) : (
            <div className="p-3 rounded-lg bg-red-500/5 border border-red-500/10 text-xs text-red-400">
              ✗ لم يتم تعيين رمز PIN. بدون PIN لن تتمكن من استعادة كلمة المرور بسهولة.
            </div>
          )}

          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">كلمة المرور للتأكيد</label>
              <Input type="password" value={pinPassword} onChange={(e) => setPinPassword(e.target.value)} className="glass-input h-10 text-sm" placeholder="أدخل كلمة المرور" dir="ltr" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">رمز PIN (4-8 أرقام)</label>
              <Input type="text" maxLength={8} value={pinCode} onChange={(e) => setPinCode(e.target.value.replace(/\D/g, ''))} className="glass-input h-10 text-sm text-center tracking-[0.3em] font-mono" placeholder="••••" dir="ltr" />
            </div>
            {settings.hasPIN && (
              <div className="space-y-1">
                <label className="text-xs text-muted-foreground">تأكيد رمز PIN الجديد</label>
                <Input type="text" maxLength={8} value={pinConfirm} onChange={(e) => setPinConfirm(e.target.value.replace(/\D/g, ''))} className="glass-input h-10 text-sm text-center tracking-[0.3em] font-mono" placeholder="••••" dir="ltr" />
              </div>
            )}
          </div>
          <button
            onClick={() => handleSave('set_pin', { action: 'set_pin', pin: pinCode, currentPassword: pinPassword })}
            disabled={loading || !pinPassword || !pinCode || pinCode.length < 4 || (settings.hasPIN && pinCode !== pinConfirm)}
            className="w-full h-11 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : settings.hasPIN ? 'تغيير PIN' : 'تعيين PIN'}
          </button>
        </div>
      )}

      {/* Social Links Section */}
      {activeSection === 'social' && (
        <div className="glass-card p-5 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
              <MessageCircle className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold">روابط التواصل الاجتماعي</h3>
              <p className="text-[10px] text-muted-foreground">الروابط تظهر للمستخدمين عبر زر التواصل العائم</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">واتساب (WhatsApp)</Label>
              <Input value={socialWhatsapp} onChange={(e) => setSocialWhatsapp(e.target.value)} className="glass-input h-10 text-sm" placeholder="967771234567" dir="ltr" />
              <p className="text-[10px] text-muted-foreground">رقم الهاتف مع رمز الدولة بدون +</p>
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">هاتف (Phone)</Label>
              <Input value={socialPhone} onChange={(e) => setSocialPhone(e.target.value)} className="glass-input h-10 text-sm" placeholder="967771234567" dir="ltr" />
              <p className="text-[10px] text-muted-foreground">رقم الهاتف المباشر مع رمز الدولة</p>
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">تيلجرام (Telegram)</Label>
              <Input value={socialTelegram} onChange={(e) => setSocialTelegram(e.target.value)} className="glass-input h-10 text-sm" placeholder="username" dir="ltr" />
              <p className="text-[10px] text-muted-foreground">اسم المستخدم بدون @</p>
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">فيسبوك (Facebook)</Label>
              <Input value={socialFacebook} onChange={(e) => setSocialFacebook(e.target.value)} className="glass-input h-10 text-sm" placeholder="https://facebook.com/..." dir="ltr" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">إنستقرام (Instagram)</Label>
              <Input value={socialInstagram} onChange={(e) => setSocialInstagram(e.target.value)} className="glass-input h-10 text-sm" placeholder="https://instagram.com/..." dir="ltr" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">تويتر (Twitter/X)</Label>
              <Input value={socialTwitter} onChange={(e) => setSocialTwitter(e.target.value)} className="glass-input h-10 text-sm" placeholder="https://twitter.com/..." dir="ltr" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">تيك توك (TikTok)</Label>
              <Input value={socialTiktok} onChange={(e) => setSocialTiktok(e.target.value)} className="glass-input h-10 text-sm" placeholder="https://tiktok.com/@..." dir="ltr" />
            </div>
          </div>

          <button
            onClick={handleSaveSocialLinks}
            disabled={loading}
            className="w-full h-11 gold-gradient text-gray-900 font-bold rounded-xl hover:opacity-90 transition-all"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'حفظ الروابط'}
          </button>
        </div>
      )}

      {/* Bot Section */}
      {activeSection === 'bot' && (
        <div className="glass-card p-5 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-medium text-sm">الروبوت الذكي</h3>
              <p className="text-[10px] text-muted-foreground">التحكم بمساعد الدعم الذكي</p>
            </div>
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
            <div>
              <p className="text-sm font-medium">تشغيل الروبوت</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                الروبوت يرد تلقائياً على أسئلة المستخدمين بالذكاء الاصطناعي
              </p>
            </div>
            <button
              onClick={toggleBotSetting}
              className={`relative w-14 h-7 rounded-full transition-colors duration-300 ${
                botEnabledSetting ? 'bg-emerald-500' : 'bg-muted'
              }`}
            >
              <span
                className={`absolute top-0.5 w-6 h-6 rounded-full bg-white shadow-md transition-transform duration-300 ${
                  botEnabledSetting ? 'translate-x-7' : 'translate-x-0.5'
                }`}
              />
            </button>
          </div>

          <div className="p-3 rounded-lg bg-gold/5 border border-gold/10">
            <p className="text-[11px] text-muted-foreground">
              {botEnabledSetting ? (
                <>🟢 الروبوت <span className="text-emerald-400 font-medium">مفعّل</span> - يظهر للمستخدمين ويجيب على أسئلتهم تلقائياً</>
              ) : (
                <>🔴 الروبوت <span className="text-red-400 font-medium">متوقف</span> - لن يظهر للمستخدمين</>
              )}
            </p>
          </div>
        </div>
      )}

      {/* Cleanup Section */}
      {activeSection === 'cleanup' && (
        <div className="glass-card p-5 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
              <Trash2 className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-red-400">تنظيف قاعدة البيانات</h3>
              <p className="text-[10px] text-muted-foreground">حذف جميع البيانات والبدء من الصفر</p>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-red-500/5 border border-red-500/10 text-xs text-red-400 space-y-2">
            <p className="font-bold">⚠️ تحذير: هذا الإجراء لا يمكن التراجع عنه!</p>
            <p>سيتم حذف:</p>
            <ul className="list-disc list-inside space-y-0.5 text-muted-foreground">
              <li>جميع المستخدمين (غير الإدارة)</li>
              <li>جميع طلبات الإيداع</li>
              <li>جميع طلبات السحب</li>
              <li>جميع المعاملات</li>
              <li>جميع الإشعارات</li>
              <li>جميع سجلات KYC</li>
              <li>جميع رموز OTP</li>
              <li>جميع بيانات الأجهزة</li>
            </ul>
            <p className="font-medium text-red-400 mt-1">سيتم الاحتفاظ بـ: حساب الإدارة، طرق الدفع، إعدادات الرسوم</p>
            <p className="font-medium text-gold">سيتم تصفير رصيد حساب الإدارة إلى 0</p>
          </div>

          {cleanupResults && (
            <div className="p-3 rounded-lg bg-green-500/5 border border-green-500/10 text-xs space-y-1">
              <p className="font-bold text-green-400">✅ تم التنظيف بنجاح:</p>
              {Object.entries(cleanupResults).map(([key, value]) => (
                <p key={key} className="text-muted-foreground">
                  {key}: <span className="text-green-400 font-medium">{value}</span>
                </p>
              ))}
            </div>
          )}

          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs text-muted-foreground">كلمة المرور للتأكيد</label>
              <Input
                type="password"
                value={cleanupPassword}
                onChange={(e) => setCleanupPassword(e.target.value)}
                className="glass-input h-10 text-sm"
                placeholder="أدخل كلمة المرور"
                dir="ltr"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-red-400 font-medium">اكتب "حذف الكل" للتأكيد</label>
              <Input
                type="text"
                value={cleanupConfirmText}
                onChange={(e) => setCleanupConfirmText(e.target.value)}
                className="glass-input h-10 text-sm border-red-500/20 focus:border-red-500/40"
                placeholder="حذف الكل"
              />
            </div>
          </div>

          <button
            onClick={handleCleanup}
            disabled={loading || !cleanupPassword || cleanupConfirmText !== 'حذف الكل'}
            className="w-full h-11 bg-red-500 text-white font-bold rounded-xl hover:bg-red-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : '🗑️ حذف جميع البيانات'}
          </button>
        </div>
      )}

      {/* ===================== DEVICES SECTION ===================== */}
      {activeSection === 'devices' && <AdminDevicesSection />}
    </div>
  )
}

// ===================== ADMIN DEVICES SECTION =====================

function AdminDevicesSection() {
  const { user } = useAuthStore()
  const [devices, setDevices] = useState<Array<{ id: string; deviceName: string; platform: string; createdAt: string; updatedAt: string }>>([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState<string | null>(null)

  const fetchDevices = useCallback(async () => {
    if (!user?.id) return
    setLoading(true)
    try {
      const res = await apiFetch('/api/user/devices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, action: 'list' }),
      })
      const data = await res.json()
      if (data.success) setDevices(data.devices || [])
    } catch {
      toast.error('خطأ في تحميل الأجهزة')
    } finally {
      setLoading(false)
    }
  }, [user?.id])

  useEffect(() => { fetchDevices() }, [fetchDevices])

  const handleRemoveDevice = async (deviceId: string) => {
    if (devices.length <= 1) {
      toast.error('لا يمكنك إزالة الجهاز الوحيد')
      return
    }
    if (!confirm('هل أنت متأكد من إزالة هذا الجهاز؟')) return
    setActionLoading(deviceId)
    try {
      const res = await apiFetch('/api/user/devices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user!.id, action: 'remove', tokenId: deviceId }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تم إزالة الجهاز بنجاح')
        fetchDevices()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('حدث خطأ')
    } finally {
      setActionLoading(null)
    }
  }

  const handleRemoveOthers = async () => {
    if (devices.length <= 1) {
      toast.error('لا توجد أجهزة أخرى للإزالة')
      return
    }
    if (!confirm(`سيتم إزالة ${devices.length - 1} جهاز آخر. هل أنت متأكد؟`)) return
    setActionLoading('all')
    try {
      const res = await apiFetch('/api/user/devices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user!.id, action: 'remove-others' }),
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.message)
        fetchDevices()
      } else {
        toast.error(data.message)
      }
    } catch {
      toast.error('حدث خطأ')
    } finally {
      setActionLoading(null)
    }
  }

  const formatDate = (dateStr: string) => {
    if (!dateStr) return 'غير محدد'
    const date = new Date(dateStr)
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (loading) {
    return (
      <div className="glass-card p-5 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gold/10 flex items-center justify-center animate-pulse">
            <Smartphone className="w-5 h-5 text-gold" />
          </div>
          <div>
            <div className="h-4 bg-white/5 rounded w-32 animate-pulse" />
            <div className="h-3 bg-white/5 rounded w-48 mt-2 animate-pulse" />
          </div>
        </div>
        {[...Array(2)].map((_, i) => (
          <div key={i} className="glass-card p-4 shimmer h-20 rounded-xl" />
        ))}
      </div>
    )
  }

  return (
    <div className="glass-card p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gold/10 flex items-center justify-center">
            <Smartphone className="w-5 h-5 text-gold" />
          </div>
          <div>
            <h3 className="text-sm font-bold">الأجهزة المسجلة</h3>
            <p className="text-[10px] text-muted-foreground">إدارة الأجهزة التي تستخدم هذا الحساب</p>
          </div>
        </div>
        <span className="px-2 py-0.5 bg-gold/10 text-gold text-[10px] font-bold rounded-full">
          {devices.length} جهاز
        </span>
      </div>

      <p className="text-xs text-muted-foreground p-2 rounded-lg bg-white/5">
        إذا كان حساب الإدارة مفتوحاً على أكثر من جهاز، يمكنك إزالة الأجهزة الأخرى من هنا. الإشعارات لن تصل للأجهزة المزالة.
      </p>

      {devices.length === 0 ? (
        <div className="text-center py-6 space-y-2">
          <Smartphone className="w-8 h-8 text-muted-foreground/30 mx-auto" />
          <p className="text-sm text-muted-foreground">لا توجد أجهزة مسجلة</p>
        </div>
      ) : (
        <div className="space-y-2">
          {devices.map((device) => (
            <div
              key={device.id}
              className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/10"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-gold/10 flex items-center justify-center">
                  <Smartphone className="w-4 h-4 text-gold" />
                </div>
                <div>
                  <p className="text-sm font-medium">{device.deviceName}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {device.platform !== 'unknown' ? device.platform.toUpperCase() : 'غير معروف'} • {formatDate(device.updatedAt || device.createdAt)}
                  </p>
                </div>
              </div>
              {devices.length > 1 && (
                <button
                  onClick={() => handleRemoveDevice(device.id)}
                  disabled={actionLoading === device.id}
                  className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center hover:bg-red-500/20 transition-colors text-red-400"
                >
                  {actionLoading === device.id ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <X className="w-3.5 h-3.5" />
                  )}
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {devices.length > 1 && (
        <button
          onClick={handleRemoveOthers}
          disabled={actionLoading === 'all'}
          className="w-full h-10 bg-red-500/10 border border-red-500/20 text-red-400 font-bold rounded-xl text-xs hover:bg-red-500/20 transition-all flex items-center justify-center gap-2"
        >
          {actionLoading === 'all' ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Trash2 className="w-4 h-4" />
          )}
          إزالة جميع الأجهزة الأخرى ({devices.length - 1})
        </button>
      )}
    </div>
  )
}
